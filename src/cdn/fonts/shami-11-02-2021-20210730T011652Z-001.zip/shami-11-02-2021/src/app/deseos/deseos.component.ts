import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NotifierService } from 'angular-notifier';
import { AuthService } from '../auth.service';
import { DsService } from '../ds.service';

@Component({
	selector: 'app-deseos',
	templateUrl: './deseos.component.html',
	styleUrls: ['./deseos.component.css']
})
export class DeseosComponent implements OnInit {

	lstCategorias;
	lstDeseos;
	idComprador;
	logueado;
	idDeseo;

	assetsImg;
	imgProducto;
	imgTienda;
	imgCategoria;

	constructor(private route: ActivatedRoute, private router: Router,
		private authService: AuthService, private notifier: NotifierService,
		private datos: DsService) { 
	}

	ngOnInit(): void {
		this.assetsImg = this.datos.getAssetsImg();
		this.imgProducto = this.datos.getImgProducto();
		this.imgTienda = this.datos.getImgTienda();
		this.imgCategoria = this.datos.getImgCategoria();
		this.obtenerCategorias();
		this.idComprador = parseInt(this.authService.getIdUsuario());
		this.obtenerListaDeseos();
		this.logueado = this.authService.isLoggedIn();
	}

	obtenerCategorias(){
		this.datos.listarCategorias()
		.subscribe(data => {
			this.lstCategorias = data;
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerListaDeseos(){
		console.log("obtenerListaDeseos -> this.idComprador: "+this.idComprador);
		this.datos.listarDeseos(this.idComprador)
		.subscribe(data => {
			console.log(data[0]);
			this.lstDeseos = data;
			console.log("this.lstDeseos: "+this.lstDeseos);
			console.log("Los datos fueron cargados.");
		});
	}

	eliminarDeseo(dato){
		this.idDeseo = dato.id;
		let deseo = {};
		deseo["id"] = this.idDeseo;
		this.datos.eliminarDeseo(deseo)
		.subscribe(data => {
			this.obtenerListaDeseos();
			this.notifier.notify( 'msg-exito', 'Eliminación exitosa.' );
			console.log(data);
		}, err => {
			if (err.status==500) {
				this.notifier.notify( 'msg-error', 'Error en la operación.' );
			}
			if (err.status==406) {
				this.notifier.notify( 'msg-error', 'Error, el deseo no existe.' );
			}
			console.log("Error en la operación: "+err.status+" err.msg ");
		});
	}

	verMasDeseos(){

	}

	irProductos(dato){
		this.router.navigateByUrl("/productos/"+dato.id);
	}

	irProducto(dato){
		this.router.navigateByUrl("/producto/"+dato.svdProducto.idProducto);
	}

	irTienda(dato){
		this.router.navigateByUrl("/tienda/"+dato.svdProducto.svdTienda.id);
	}

}
