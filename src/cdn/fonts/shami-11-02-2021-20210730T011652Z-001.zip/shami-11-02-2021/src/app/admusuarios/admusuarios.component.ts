import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NotifierService } from 'angular-notifier';
import { AuthService } from '../auth.service';
import { DsService } from '../ds.service';

@Component({
	selector: 'app-admusuarios',
	templateUrl: './admusuarios.component.html',
	styleUrls: ['./admusuarios.component.css']
})
export class AdmusuariosComponent implements OnInit {

	lstUsuarios;
	lstRoles;
	nombres;
	apPaterno;
	apMaterno;
	sexo="M";
	fechaNacimiento;
	idDep;
	idProv;
	idDist;
	departamento;
	provincia;
	distrito;
	urbanizacion;
	sector;
	manzana;
	lote;
	direccionFacturacion="";
	codigoPostal;
	dni;
	correo;
	telefono;
	celular;
	pais="Perú";
	clave;
	idRol=1;
	idPer;
	idUsuario;
	mostrarFormulario=false;
	btnTitulo="Registrar";
	crud=0;
	modal="";
	lstDepartamentos;
	lstProvincias;
	lstDistritos;
	idRolAuth;

	buscarApellidoPaterno;

	constructor(private route: ActivatedRoute, private router: Router,
		private authService: AuthService, private notifier: NotifierService,
		private datos: DsService) { }

	ngOnInit(): void {
		this.idRolAuth = parseInt(this.authService.getIdRol());
		this.idUsuario = parseInt(this.authService.getIdUsuario());
		if (this.idRolAuth==4) {
			this.obtenerUsuarios();
			this.obtenerRoles();
			this.obtenerDepartamentos();
		}
		if (this.idRolAuth==1) {
			this.obtenerRepartidores();
			this.obtenerDepartamentos();
			this.idRol = 2; //repartidor
		}
	}

	onChangeDepartamento(obj){
		let objeto = JSON.parse(obj);
		console.log("entries: "+Object.entries(objeto));
		this.idDep = objeto.svdDepartamentoPK.idDpto;
		this.departamento = objeto.nombreDpto;
		this.obtenerProvincias(this.idDep);
	}

	onChangeProvincia(obj){
		let objeto = JSON.parse(obj);
		console.log("entries: "+Object.entries(objeto));
		this.idProv = objeto.svdProvinciaPK.idProv;
		this.provincia = objeto.nombreProv;
		this.obtenerDistritos(this.idDep,this.idProv);
	}

	onChangeDistrito(obj){
		let objeto = JSON.parse(obj);
		console.log("entries: "+Object.entries(objeto));
		this.distrito = objeto.nombreDist;
	}

	obtenerDepartamentos(){
		this.datos.listarDepartamentos()
		.subscribe(data => {
			this.lstDepartamentos = data;
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerProvincias(idDep){
		this.datos.listarProvincias(idDep)
		.subscribe(data => {
			this.lstProvincias = data;
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerDistritos(idDep,idProv){
		this.datos.listarDistritos(idDep,idProv)
		.subscribe(data => {
			this.lstDistritos = data;
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerProvinciasDistritos(){
		this.datos.listarProvincias(this.idDep)
		.subscribe(data => {
			this.lstProvincias = data;
			this.obtenerDistritos(this.idDep,this.idProv);
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerUsuarios(){
		this.datos.listarUsuarios()
		.subscribe(data => {
			console.log(data[0]);
			this.lstUsuarios = data;
			console.log("this.lstUsuarios: "+this.lstUsuarios);
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerVendedores(){
		this.datos.listarVendedores()
		.subscribe(data => {
			console.log(data[0]);
			this.lstUsuarios = data;
			console.log("this.lstUsuarios: "+this.lstUsuarios);
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerRepartidores(){
		this.datos.listarRepartidores()
		.subscribe(data => {
			console.log(data[0]);
			this.lstUsuarios = data;
			console.log("this.lstUsuarios: "+this.lstUsuarios);
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerCompradores(){
		this.datos.listarCompradores()
		.subscribe(data => {
			console.log(data[0]);
			this.lstUsuarios = data;
			console.log("this.lstUsuarios: "+this.lstUsuarios);
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerAdministradores(){
		this.datos.listarAdministradores()
		.subscribe(data => {
			console.log(data[0]);
			this.lstUsuarios = data;
			console.log("this.lstUsuarios: "+this.lstUsuarios);
			console.log("Los datos fueron cargados.");
		});
	}

	buscarUsuarioPorApellido(){
		this.datos.buscarUsuarioApellido(this.buscarApellidoPaterno)
		.subscribe(data => {
			console.log(data[0]);
			this.lstUsuarios = data;
			console.log("this.lstUsuarios: "+this.lstUsuarios);
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerRoles(){
		this.datos.listarRoles()
		.subscribe(data => {
			console.log(data[0]);
			this.lstRoles = data;
			console.log("this.lstRoles: "+this.lstRoles);
			console.log("Los datos fueron cargados.");
		});
	}

	crearUsuario(){
		let svdRolUsuarios = {};
		svdRolUsuarios["id"] = this.idRol;
		let svdPersona = {};
		svdPersona["nombres"] = this.nombres;
		svdPersona["apPaterno"] = this.apPaterno;
		svdPersona["apMaterno"] = this.apMaterno;
		svdPersona["sexo"] = this.sexo;
		svdPersona["fechaNacimiento"] = this.fechaNacimiento;
		svdPersona["idDep"] = this.idDep;
		svdPersona["idProv"] = this.idProv;
		svdPersona["idDist"] = this.idDist;
		svdPersona["codigoPostal"] = this.codigoPostal;
		svdPersona["departamento"] = this.departamento;
		svdPersona["provincia"] = this.provincia;
		svdPersona["distrito"] = this.distrito;
		svdPersona["urbanizacion"] = this.urbanizacion;
		svdPersona["sector"] = this.sector;
		svdPersona["manzana"] = this.manzana;
		svdPersona["lote"] = this.lote;
		svdPersona["direccionFacturacion"] = this.direccionFacturacion;
		svdPersona["dni"] = this.dni;
		svdPersona["correo"] = this.correo;
		svdPersona["telefono"] = this.telefono;
		svdPersona["celular"] = this.celular;
		let usuario = {};
		usuario["usuario"] = this.correo;
		usuario["clave"] = this.clave;
		usuario["svdPersona"] = svdPersona;
		usuario["svdRolUsuarios"] = svdRolUsuarios;
		this.datos.crearUsuario(usuario)
		.subscribe(data => {
			this.notifier.notify( 'msg-exito', 'Registro exitoso.' );
			console.log(data);
			if (this.idRolAuth==4) {
				this.obtenerUsuarios();
			}
			if (this.idRolAuth==1) {
				this.obtenerRepartidores();
			}
		}, err => {
			if (err.status==500) {
				this.notifier.notify( 'msg-error', 'Error en la operación.' );
			}
			if (err.status==406) {
				this.notifier.notify( 'msg-error', 'Error, el usuario ya existe.' );
			}
			console.log("Error en la operación: "+err.status+" err.msg ");
		});
	}

	actualizarUsuario(){
		let svdRolUsuarios = {};
		svdRolUsuarios["id"] = this.idRol;
		let svdPersona = {};
		svdPersona["idPer"] = this.idPer; //Id persona
		svdPersona["nombres"] = this.nombres;
		svdPersona["apPaterno"] = this.apPaterno;
		svdPersona["apMaterno"] = this.apMaterno;
		svdPersona["sexo"] = this.sexo;
		svdPersona["fechaNacimiento"] = this.fechaNacimiento;
		svdPersona["idDep"] = this.idDep;
		svdPersona["idProv"] = this.idProv;
		svdPersona["idDist"] = this.idDist;
		svdPersona["codigoPostal"] = this.codigoPostal;
		svdPersona["departamento"] = this.departamento;
		svdPersona["provincia"] = this.provincia;
		svdPersona["distrito"] = this.distrito;
		svdPersona["urbanizacion"] = this.urbanizacion;
		svdPersona["sector"] = this.sector;
		svdPersona["manzana"] = this.manzana;
		svdPersona["lote"] = this.lote;
		svdPersona["direccionFacturacion"] = this.direccionFacturacion;
		svdPersona["dni"] = this.dni;
		svdPersona["correo"] = this.correo;
		svdPersona["telefono"] = this.telefono;
		svdPersona["celular"] = this.celular;
		let usuario = {};
		usuario["id"] = this.idUsuario;
		usuario["usuario"] = this.correo;
		//usuario["clave"] = this.clave;
		usuario["svdPersona"] = svdPersona;
		usuario["svdRolUsuarios"] = svdRolUsuarios;
		this.datos.actualizarUsuario(usuario)
		.subscribe(data => {
			this.notifier.notify( 'msg-exito', 'Actualización exitosa.' );
			console.log(data);
			if (this.idRolAuth==4) {
				this.obtenerUsuarios();
			}
			if (this.idRolAuth==1) {
				this.obtenerRepartidores();
			}
		}, err => {
			if (err.status==500) {
				this.notifier.notify( 'msg-error', 'Error en la operación.' );
			}
			if (err.status==406) {
				this.notifier.notify( 'msg-error', 'Error, no existe el usuario.' );
			}
			console.log("Error en la operación: "+err.status+" err.msg ");
		});
	}

	eliminarUsuario(){
		//this.cerrarModal();
		let usuario = {};
		usuario["id"] = this.idUsuario;
		let svdPersona = {};
		svdPersona["idPer"] = this.idPer; //Id persona
		usuario["svdPersona"] = svdPersona;
		this.datos.eliminarUsuario(usuario)
		.subscribe(data => {
			this.notifier.notify( 'msg-exito', 'Eliminación exitosa.' );
			console.log(data);
			this.obtenerUsuarios();
		}, err => {
			if (err.status==500) {
				this.notifier.notify( 'msg-error', 'Error en la operación.' );
			}
			if (err.status==406) {
				this.notifier.notify( 'msg-error', 'Error, no existe el usuario.' );
			}
			console.log("Error en la operación: "+err.status+" err.msg ");
		});
	}

	habilitacionUsuario(dato,estado){
		let usuario = {};
		usuario["id"] = dato.id;
		usuario["habilitado"] = estado;
		this.datos.habilitacionUsuario(usuario)
		.subscribe(data => {
			this.notifier.notify( 'msg-exito', 'Configuración exitosa.' );
			console.log(data);
			this.obtenerUsuarios();
		}, err => {
			if (err.status==500) {
				this.notifier.notify( 'msg-error', 'Error en la operación.' );
			}
			if (err.status==406) {
				this.notifier.notify( 'msg-error', 'Error, no existe el usuario.' );
			}
			console.log("Error en la operación: "+err.status+" err.msg ");
		});
	}

	resetearClaveUsuario(dato){
		let usuario = {};
		usuario["id"] = dato.id;
		this.datos.resetearClaveUsuario(usuario)
		.subscribe(data => {
			this.notifier.notify( 'msg-exito', 'Clave reseteada a 12345678.' );
			console.log(data);
			this.obtenerUsuarios();
		}, err => {
			if (err.status==500) {
				this.notifier.notify( 'msg-error', 'Error en la operación.' );
			}
			if (err.status==406) {
				this.notifier.notify( 'msg-error', 'Error, no existe el usuario.' );
			}
			console.log("Error en la operación: "+err.status+" err.msg ");
		});
	}

	editarDatos(dato){
		this.idRol = dato.svdRolUsuarios.id; //Id rol
		console.log("dato.svdRolUsuarios.id de editarDatos: "+dato.svdRolUsuarios.id);
		this.idPer = dato.svdPersona.idPer; //Id persona
		this.nombres = dato.svdPersona.nombres;
		this.apPaterno = dato.svdPersona.apPaterno;
		this.apMaterno = dato.svdPersona.apMaterno;
		this.sexo = dato.svdPersona.sexo;
		this.fechaNacimiento = dato.svdPersona.fechaNacimiento;
		this.idDep = dato.svdPersona.idDep;
		this.idProv = dato.svdPersona.idProv;
		this.idDist = dato.svdPersona.idDist;
		//this.obtenerProvincias(this.idDep);
		//this.obtenerDistritos(this.idDep,this.idProv);
		this.obtenerProvinciasDistritos();
		this.departamento = dato.svdPersona.departamento;
		this.provincia = dato.svdPersona.provincia;
		this.distrito = dato.svdPersona.distrito;
		this.codigoPostal = dato.svdPersona.codigoPostal;
		this.urbanizacion = dato.svdPersona.urbanizacion;
		this.sector = dato.svdPersona.sector;
		this.manzana = dato.svdPersona.manzana;
		this.lote = dato.svdPersona.lote;
		this.direccionFacturacion = dato.svdPersona.direccionFacturacion;
		this.dni = dato.svdPersona.dni;
		this.correo = dato.svdPersona.correo;
		this.telefono = dato.svdPersona.telefono;
		this.celular = dato.svdPersona.celular;
		this.idUsuario = dato.id; //Id usuario
		//this.clave = dato.clave;
		this.mostrarFormulario=true;
		this.crud = 2;
		this.btnTitulo="Actualizar";
	}

	eliminarDatos(dato){
		this.idUsuario = dato.id; //Id usuario
		this.idPer = dato.svdPersona.idPer; //Id persona
		//this.abrirModal();
		this.eliminarUsuario();
		this.crud = 3;
	}

	btnGuardar(){
		if (this.crud==1) { //Registrar
			this.crearUsuario();
		}
		if (this.crud==2) { //Actualizar
			this.actualizarUsuario();
		}
	}

	btnCancelar(){
		this.crud = 1;
		this.btnTitulo="Registrar";
		this.mostrarFormulario=false;
	}

	nuevoUsuario(){
		this.mostrarFormulario=true;
		this.crud=1;
		this.btnTitulo="Registrar";
	}

	validarCorreo(correo){
 		if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(correo)){
    		return true;
  		}
    	return false;
	}

	validarClave(clave){
		let strClave = clave+"";
 		if (strClave.length<=30 && strClave.length>=8){
    		return true;
  		}
    	return false;
	}

	filtrarPorRol(){
		if (this.idRol==1) {
			this.obtenerVendedores();
		}
		if (this.idRol==2) {
			this.obtenerRepartidores();
		}
		if (this.idRol==3) {
			this.obtenerCompradores();
		}
		if (this.idRol==4) {
			this.obtenerAdministradores();
		}
	}

}
