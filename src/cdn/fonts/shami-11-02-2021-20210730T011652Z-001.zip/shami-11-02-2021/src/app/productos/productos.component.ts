import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NotifierService } from 'angular-notifier';
import { AuthService } from '../auth.service';
import { DsService } from '../ds.service';
import { MetadataService } from '../metadata.service';

@Component({
	selector: 'app-productos',
	templateUrl: './productos.component.html',
	styleUrls: ['./productos.component.css']
})
export class ProductosComponent implements OnInit {

	lstCategorias;
	lstSubcategorias;
	nombreCategoria="categoria";
	figuraCategoria="";
	nombreSubcategoria="Seleccionar...";
	imgProducto;
	imgCategoria;
	lstProductosPorCategoria;
	lstProductosPorSubcategoria;
	paginaCategoria=1;
	cantidadCategoria=8;
	idCategoria=1;

	idProducto;
	idComprador;
	logueado;

	idSubcategoria;

	constructor(private route: ActivatedRoute, private router: Router,
	private authService: AuthService, private notifier: NotifierService,
	private datos: DsService, private metadata: MetadataService) { }

	ngOnInit(): void {
		this.route.params.subscribe(params=>{
			this.idCategoria = params['id'];
			this.obtenerProductosPorCategoriaPaginados();
			console.log("params "+params['id']);
			let url = 'productos/'+this.idCategoria;
			this.metadata.updateTags('Productos', url);
		})
		this.obtenerCategoriaPorId(this.idCategoria);
		this.obtenerSubcategoriasPorCategorias(this.idCategoria);
		this.imgProducto = this.datos.getImgProducto();
		this.imgCategoria = this.datos.getImgCategoria();
		this.obtenerCategorias();
		this.idComprador = parseInt(this.authService.getIdUsuario());
		this.logueado = this.authService.isLoggedIn();
	}

	crearDeseo(dato){
		if (this.logueado) {
			this.idProducto = dato.idProducto;
			let deseo = {};
			let svdProducto = {};
			svdProducto["idProducto"] = this.idProducto;
			deseo["svdProducto"] = svdProducto;
			let svdUsuarios = {}
			svdUsuarios["id"] = this.idComprador;
			deseo["svdUsuarios"] = svdUsuarios;
			this.datos.crearDeseo(deseo)
			.subscribe(data => {
				this.notifier.notify( 'msg-exito', 'Producto agregado a lista de deseos.' );
				console.log(data);
			}, err => {
				if (err.status==500) {
					this.notifier.notify( 'msg-error', 'Error en la operación.' );
				}
				if (err.status==406) {
					this.notifier.notify( 'msg-error', 'Error, el vendedor ya tiene tienda.' );
				}
				console.log("Error en la operación: "+err.status+" err.msg ");
			});
		} else {
			this.notifier.notify( 'msg-error', 'Debe iniciar sesión.' );
		}
	}

	obtenerCategorias(){
		this.datos.listarCategorias()
		.subscribe(data => {
			this.lstCategorias = data;
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerCategoriaPorId(id){
		this.datos.listarCategoriaPorId(id)
		.subscribe(data => {
			this.nombreCategoria = data['categoria'];
			this.figuraCategoria = data['figura'];
			console.log("nombreCategoria: "+this.nombreCategoria);
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerSubcategoriasPorCategorias(id){
		this.datos.listarSubcategoriasPorCategorias(id)
		.subscribe(data => {
			this.lstSubcategorias = data;
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerProductosPorCategoriaPaginados(){
		this.datos.paginarProductosPorCategoria(this.paginaCategoria,this.cantidadCategoria,this.idCategoria)
		.subscribe(data => {
			this.lstProductosPorCategoria = data;
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerProductosPorSubcategoriaPaginados(idSubcategoria){
		this.idSubcategoria = idSubcategoria;
		this.datos.paginarProductosPorSubcategoria(this.paginaCategoria,this.cantidadCategoria,idSubcategoria)
		.subscribe(data => {
			this.lstProductosPorCategoria = data;
			console.log("Los datos fueron cargados.");
		});
	}

	cargarPorSubcategoria(dato){
		this.nombreSubcategoria = dato.subcategoria;
		this.obtenerProductosPorSubcategoriaPaginados(dato.id);
	}

	cargarPorCategoria(dato){
		this.router.navigateByUrl("/productos/"+dato.id);
		this.idCategoria = dato.id;
		this.obtenerProductosPorCategoriaPaginados();
		this.obtenerCategoriaPorId(this.idCategoria);
		this.obtenerSubcategoriasPorCategorias(this.idCategoria);
	}

	verMasProductos(){
		this.paginaCategoria = this.paginaCategoria+1;
		this.datos.paginarProductosPorSubcategoria(this.paginaCategoria,this.cantidadCategoria, this.idSubcategoria)
		.subscribe(data => {
			if (data!=null) {
				this.lstProductosPorCategoria = this.lstProductosPorCategoria.concat(data);
			} else {

			}
			console.log("Los datos fueron cargados.");
		});
	}

	irProducto(dato){
		this.router.navigateByUrl("/producto/"+dato.idProducto);
	}

	irTienda(dato){
		this.router.navigateByUrl("/tienda/"+dato.svdTienda.id);
	}

}
