import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NotifierService } from 'angular-notifier';
import { AuthService } from '../auth.service';
import { DsService } from '../ds.service';
import { MetadataService } from '../metadata.service';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

@Component({
	selector: 'app-producto',
	templateUrl: './producto.component.html',
	styleUrls: ['./producto.component.css']
})
export class ProductoComponent implements OnInit {

	lstCategorias;
	lstSubcategorias;
	nombreCategoria="categoria";
	figuraCategoria="";
	nombreSubcategoria="Seleccionar...";
	productoEspecifico;
	nombreProducto="Producto";
	descripcion;
	urlImagen="";
	urlImagenA;
	urlImagenB;
	urlImagenC;
	cantidad=1;
	datosProducto;
	stock;
	nombreTienda;
	idTienda;
	precio;
	idProducto;
	imgProducto;
	imgCategoria;
	lstProductosPorCategoria;
	paginaCategoria=1;
	cantidadCategoria=8;
	idCategoria=1;

	idComprador;
	logueado;
	urlImagenDefecto=this.urlImagen;

	constructor(private route: ActivatedRoute, private router: Router,
		private authService: AuthService, private notifier: NotifierService,
		private datos: DsService, private metadata: MetadataService,
		private modalService: NgbModal) { }

	ngOnInit(): void {
		this.route.params.subscribe(params=>{
			this.idProducto = params['id'];
			this.obtenerProductosPorCategoriaPaginados();
			this.obtenerProducto();
			let url = 'producto/'+this.idProducto;
			this.metadata.updateTags('Producto', url);
		})
		this.imgProducto = this.datos.getImgProducto();
		this.imgCategoria = this.datos.getImgCategoria();
		this.obtenerCategorias();
		this.idComprador = parseInt(this.authService.getIdUsuario());
		this.logueado = this.authService.isLoggedIn();
	}

	obtenerCategorias(){
		this.datos.listarCategorias()
		.subscribe(data => {
			this.lstCategorias = data;
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerSubcategoriasPorCategorias(id){
		this.datos.listarSubcategoriasPorCategorias(id)
		.subscribe(data => {
			this.lstSubcategorias = data;
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerProductosPorCategoriaPaginados(){
		this.datos.paginarProductosPorCategoria(this.paginaCategoria,this.cantidadCategoria,this.idCategoria)
		.subscribe(data => {
			this.lstProductosPorCategoria = data;
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerProducto(){
		this.datos.productoEspecifico(this.idProducto)
		.subscribe(data => {
			this.productoEspecifico = data;
			this.datosProducto = data;
			this.nombreProducto = data['nombreProducto'];
			this.descripcion = data['descripcion'];
			this.urlImagen = data['urlImagen'];
			this.urlImagenA = data['urlImagenA'];
			this.urlImagenB = data['urlImagenB'];
			this.urlImagenC = data['urlImagenC'];
			this.urlImagenDefecto = this.urlImagen;
			this.nombreTienda = data['svdTienda'].nombreTienda;
			this.idTienda = data['svdTienda'].id;
			this.idCategoria = data['svdSubcategorias'].svdCategorias.id;
			this.nombreCategoria = data['svdSubcategorias'].svdCategorias.categoria;
			this.figuraCategoria = data['svdSubcategorias'].svdCategorias.figura;
			this.obtenerSubcategoriasPorCategorias(this.idCategoria);
			this.nombreSubcategoria = data['svdSubcategorias'].subcategoria;
			this.precio = data['precio'];
			this.stock = data['stock'];
			console.log("Los datos fueron cargados.");
		});
	}

	agregarAlCarrito(){
		if (this.logueado) {
			let carrito = {};
			let svdProducto = {};
			svdProducto["idProducto"] = this.datosProducto.idProducto;
			carrito["svdProducto"] = svdProducto;
			let svdUsuarios = {}
			svdUsuarios["id"] = this.idComprador;
			carrito["svdUsuarios"] = svdUsuarios;
			let svdFasesOrden = {};
			svdFasesOrden["id"] = 1;
			carrito["svdFasesOrden"] = svdFasesOrden;
			let svdTiposPago = {};
			svdTiposPago["id"] = 0;
			carrito["svdTiposPago"] = svdTiposPago;
			carrito["cantidad"] = this.cantidad;
			console.log("this.cantidad*dato.precio :"+this.cantidad*this.datosProducto.precio);
			carrito["costo"] = this.cantidad*this.datosProducto.precio;
			this.datos.crearCarrito(carrito)
			.subscribe(data => {
				this.notifier.notify( 'msg-exito', 'Producto agregado al carrito.' );
				this.router.navigateByUrl("/carrito");
				console.log(data);
			}, err => {
				if (err.status==500) {
					this.notifier.notify( 'msg-error', 'Error en la operación.' );
				}
				if (err.status==406) {
					this.notifier.notify( 'msg-error', 'Error...' );
				}
				console.log("Error en la operación: "+err.status+" err.msg ");
			});
		} else {
			this.notifier.notify( 'msg-error', 'Debe iniciar sesión.' );
		}
	}

	cargarPorCategoria(dato){
		this.router.navigateByUrl("/productos/"+dato.id);
	}

	irProductosPorCategoria(dato){
		this.router.navigateByUrl("/productos/"+dato.svdCategorias.id);
	}

	irProducto(dato){
		this.router.navigateByUrl("/producto/"+dato.idProducto);
	}

	irTienda(dato){
		this.router.navigateByUrl("/tienda/"+dato.svdTienda.id);
	}

	irTiendaPorId(){
		this.router.navigateByUrl("/tienda/"+this.idTienda);
	}

	verMasProductos(){}

	mas(){
		if (this.cantidad<this.stock) {
			this.cantidad= this.cantidad+1;
		} else {
			this.notifier.notify( 'msg-error', 'No se puede exceder.' );
		}
	}

	menos(){
		if (this.cantidad<=1) {
			this.notifier.notify( 'msg-error', 'No se puede comprar menos de 1 producto.' );
		} else {
			this.cantidad= this.cantidad-1;
		}
	}

	mostrarImagen(img){
		this.urlImagenDefecto = this.urlImagen;
		if (img=='A') {
			this.urlImagenDefecto = this.urlImagenA;
		}
		if (img=='B') {
			this.urlImagenDefecto = this.urlImagenB;
		}
		if (img=='C') {
			this.urlImagenDefecto = this.urlImagenC;
		}
	}

	acercarImagen(content){
		this.abriModal(content);
	}

	abriModal(content) {
		this.modalService.open(content, { size: 'lg' })
		.result.then((result) => {
			//this.closeResult = `Closed with: ${result}`;
		}, (reason) => {
			//this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
		});
	}

	contarCaracteres(img){
		let cad = "";
		cad = img;
		if (cad!="undefined" && cad!=null) {
			console.log("no es undefined.");
			if (cad.length>2) {
			return true;
			}
		}
		
		return false;
	}

}
