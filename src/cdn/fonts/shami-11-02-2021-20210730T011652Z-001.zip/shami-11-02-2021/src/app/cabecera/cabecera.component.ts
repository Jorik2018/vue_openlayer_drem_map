import { Component, OnInit } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { Router, ActivatedRoute } from '@angular/router';
import { NotifierService } from 'angular-notifier';
import { NgxSpinnerService } from 'ngx-spinner';
import { AuthService } from '../auth.service';
import { DsService } from '../ds.service';

@Component({
	selector: 'cabecera',
	templateUrl: './cabecera.component.html',
	styleUrls: ['./cabecera.component.css']
})
export class CabeceraComponent implements OnInit {

	closeResult = '';
	isMenuCollapsed = true;
	activeModal=1;
	assetsImg;

	usuario;
  	clave;
  	claveRegistro;
  	repetirClave;
  	correo;
  	nombres;
  	apPaterno;
  	apMaterno;
  	correoRecuperacion;
  	codigoRecuperacion;
  	ruc;
  	razonSocial;

  	_bandLogueado=false;

  	nombrePersona;
  	imgPerfil;

  	buscarPalabra;
    lstResultadosBusqueda;
    mostrarResultados="";

    imgProducto;
    tipoUsuario=-1;

    activarRecuperarClave=false;

    _nombreUsuario;

	constructor(private modalService: NgbModal, private route: ActivatedRoute, 
		private router: Router, private authService: AuthService, 
		private notifier: NotifierService, private datos: DsService,
		private spinner: NgxSpinnerService) {
	}

	ngOnInit(): void {
		if (this.authService.isLoggedIn()) {
           this.traerDatosPersonaPorId();
        }
		this.assetsImg = this.datos.getAssetsImg();
		this.imgProducto = this.datos.getImgProducto();
	}

	get bandLogueado() {
        this._bandLogueado = this.authService.isLoggedIn();
        return this._bandLogueado;
    }

    get nombreUsuario() {
        this._nombreUsuario = this.authService.getNombreUsuario();
        return this._nombreUsuario;
    }

	abrirModal(content) {
		this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
			this.closeResult = `Closed with: ${result}`;
		}, (reason) => {
			this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
		});
	}

	getDismissReason(reason: any): string {
		if (reason === ModalDismissReasons.ESC) {
			return 'by pressing ESC';
		} else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
			return 'by clicking on a backdrop';
		} else {
			return `with: ${reason}`;
		}
	}

	autenticarse() {
	    this.usuario=this.usuario+"";
	    this.clave=this.clave+"";
	    if (this.usuario!='' && this.usuario!=="undefined" && this.clave!='' && this.clave!=="undefined") {
	    	let correoValido = this.validarCorreo(this.usuario);
	    	let claveValida = this.validarClave(this.clave);
	    	if (correoValido && claveValida) {
	    		this.authService.obtenerAuth(this.usuario, this.clave);
	    		//this.modalService.dismissAll();
	    	} else {
	    		console.log("La credenciales no son válidas.");
				this.notifier.notify( 'msg-error', 'La credenciales no son válidas.' );
	    	}
	    } else {
			console.log("Ingrese sus credenciales.");
			this.notifier.notify( 'msg-exito', 'Ingrese sus credenciales.' );
	    }
	    this.usuario="";
	    this.clave="";
  	}

  	cerrarSesion(){
        this.spinner.show();
        setTimeout(() => {
            this.spinner.hide();
            this.authService.logout();
            //this.bandLogueado = false;
            this.router.navigateByUrl("/inicio");
        }, 1000);
    }

    registrarse(){
    	if (this.tipoUsuario==3) {
    		this.nombres="-";
			this.apPaterno="-";
			this.apMaterno="-";
    		this.registrarseComoComprador();
    	}
    	if (this.tipoUsuario==1) {
			this.nombres="-";
			this.apPaterno="-";
			this.apMaterno="-";
			this.ruc="-";
			this.razonSocial="-";
    		this.registrarseComoVendedor();
    	}
    	if (this.tipoUsuario!=3 && this.tipoUsuario!=1) {
    		this.notifier.notify( 'msg-exito', 'Debe seleccionar un tipo de usuario.' );
    	}
    }

    registrarseComoComprador(){
		let svdPersona = {};
		svdPersona["correo"] = this.correo;
		svdPersona["nombres"] = this.nombres;
		svdPersona["apPaterno"] = this.apPaterno;
		svdPersona["apMaterno"] = this.apMaterno;
		let usuario = {};
		usuario["usuario"] = this.correo;
		usuario["clave"] = this.claveRegistro;
		usuario["svdPersona"] = svdPersona;
		this.datos.crearCuenta(usuario)
		.subscribe(data => {
			this.notifier.notify( 'msg-exito', 'Registro exitoso.' );
			this.usuario = this.correo;
			this.clave = this.claveRegistro;
			this.autenticarse();
			console.log(data);
		}, err => {
			if (err.status==500) {
				this.notifier.notify( 'msg-error', 'Error en la operación.' );
			}
			if (err.status==406) {
				this.notifier.notify( 'msg-error', 'El correo ya existe.' );
			}
			console.log("Error en la operación: "+err.status+" err.msg ");
		});
	}

	registrarseComoVendedor(){
		let svdPersona = {};
		svdPersona["correo"] = this.correo;
		svdPersona["nombres"] = this.nombres;
		svdPersona["apPaterno"] = this.apPaterno;
		svdPersona["apMaterno"] = this.apMaterno;
		svdPersona["ruc"] = this.ruc;
		svdPersona["razonSocial"] = this.razonSocial
		let usuario = {};
		usuario["usuario"] = this.correo;
		usuario["clave"] = this.claveRegistro;
		usuario["svdPersona"] = svdPersona;
		this.datos.crearCuentaVendedor(usuario)
		.subscribe(data => {
			this.notifier.notify( 'msg-exito', 'Registro exitoso.' );
			this.usuario = this.correo;
			this.clave = this.claveRegistro;
			this.autenticarse();
			console.log(data);
		}, err => {
			if (err.status==500) {
				this.notifier.notify( 'msg-error', 'Error en la operación.' );
			}
			if (err.status==406) {
				this.notifier.notify( 'msg-error', 'El correo ya existe.' );
			}
			if (err.status==400) {
				this.notifier.notify( 'msg-error', 'Todos los campos deben estar llenos.' );
			}
			console.log("Error en la operación: "+err.status+" err.msg ");
		});
	}

	mandarCorreo(){
		this.datos.enviarCorreoRecuperacion(this.correoRecuperacion)
		.subscribe(data => {
			this.notifier.notify( 'msg-exito', 'Correo enviado.' );
			console.log(data);
		}, err => {
			if (err.status==500) {
				this.notifier.notify( 'msg-error', 'Error en la operación.' );
			}
			if (err.status==406) {
				this.notifier.notify( 'msg-error', 'El correo no existe.' );
			}
			console.log("Error en la operación: "+err.status+" err.msg ");
		});
	}

	olvidoClave(){
		this.activarRecuperarClave=true;
	}

	regresarLogueo(){
		this.activarRecuperarClave=false;
	}

    traerDatosPersonaPorId(){
        let id = this.authService.getIdPer();
        if (id==null) {
            this.notifier.notify( 'msg-error', 'Usted debe estar logueado.' );
        } else {
            this.datos.datosPersonaPorId(id)
            .subscribe(data => {
                //this.notifier.notify( 'msg-exito', 'Registro exitoso.' );
                this.nombrePersona = data['nombres'];
                this.imgPerfil = data['urlPerfil'];
            }, err => {
                if (err.status==500) {
                    this.notifier.notify( 'msg-error', 'Error al traer datos personales.' );
                }
            });
        }
        
    }

    traerlistaBuscarProductoPorNombre(){
        this.datos.listarBuscarProductoPorNombre(this.buscarPalabra)
            .subscribe(data => {
                //this.notifier.notify( 'msg-exito', 'Registro exitoso.' );
                this.lstResultadosBusqueda = data;
                let resultados = 0;
                resultados = this.lstResultadosBusqueda.length;
                if (resultados>0) {
                    this.mostrarResultados = "abierto";
                    this.notifier.notify( 'msg-exito', 'Se encontraron resultados.' );
                } else {
                    this.mostrarResultados = "";
                    this.notifier.notify( 'msg-error', 'No se encontraron resultados.' );
                }
            }, err => {
                if (err.status==500) {
                    this.mostrarResultados = "";
                    this.notifier.notify( 'msg-error', 'No se encontraron resultados.' );
                }
            });
    }

  	validarCorreo(correo){
 		if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(correo)){
    		return true;
  		}
    	return false;
	}

	validarClave(clave){
		let strClave = clave+"";
 		if (strClave.length<=30 && strClave.length>=8){
    		return true;
  		}
    	return false;
	}

	validarRepetirClave(clave,repetirClave){
		if (clave==repetirClave) {
			return true;
		} 
		return false;
	}

	irInicio(){
    	this.router.navigateByUrl("/inicio");
    }

    irTiendas(){
		this.router.navigateByUrl("/tiendas/1");
	}

	irListaDeseos() {
		this.router.navigateByUrl("/deseos");
	}

	irCuenta(){
		this.router.navigateByUrl("/cuenta");
	}

	irPedidos(){
		this.router.navigateByUrl("/pedidos");
	}

	irCarrito(){
		this.router.navigateByUrl("/carrito");
	}

	irProducto(dato){
		this.router.navigateByUrl("/producto/"+dato.idProducto);
		this.mostrarResultados = "";
	}

}
