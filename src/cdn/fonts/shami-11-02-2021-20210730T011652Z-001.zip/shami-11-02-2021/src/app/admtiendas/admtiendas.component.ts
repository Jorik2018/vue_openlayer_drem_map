import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NotifierService } from 'angular-notifier';
import { AuthService } from '../auth.service';
import { DsService } from '../ds.service';

@Component({
	selector: 'app-admtiendas',
	templateUrl: './admtiendas.component.html',
	styleUrls: ['./admtiendas.component.css']
})
export class AdmtiendasComponent implements OnInit {

	lstTiendas;
	lstCategorias;
	lstVendedores;
	idTienda;
	nombreTienda;
	descripcion;
	idCategoria;
	idVendedor;
	direccion;
	mapa;
	logo="-";
	tienda="-";
	video;
	mostrarFormulario=false;
	btnTitulo="Registrar";
	crud=0;
	modal="";
	idRol;
	idUsuario;

	horarioAtencion;
	telefono;
	paginaWeb;
	urlPaginaWeb;
	facebook;
	urlFacebook;
	instagram;
	urlInstagram;
	twitter;
	urlTwitter
	youtube;
	urlYoutube;

	archivo = [];

	nombreTiendaNum=0;
	descripcionNum=0;

	constructor(private route: ActivatedRoute, private router: Router,
		private authService: AuthService, private notifier: NotifierService,
		private datos: DsService) { }

	ngOnInit(): void {
		this.idRol = parseInt(this.authService.getIdRol());
		this.idUsuario = parseInt(this.authService.getIdUsuario());
		if (this.idRol==4) {
			this.obtenerTiendas();
			this.obtenerVendedores();
		}
		if (this.idRol==1) {
			this.btnTitulo="Actualizar";
			this.obtenerTiendasPorIdVendedor();
			this.idVendedor = this.idUsuario;

		}
		this.obtenerCategorias();
	}

	obtenerTiendas(){
		this.datos.listarTiendas()
		.subscribe(data => {
			console.log(data[0]);
			this.lstTiendas = data;
			console.log("this.lstTiendas: "+this.lstTiendas);
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerTiendasPorIdVendedor(){
		this.datos.listarTiendasPorIdVendedor(this.idUsuario)
		.subscribe(data => {
			console.log(data[0]);
			this.lstTiendas = data;
			console.log("this.lstTiendas: "+this.lstTiendas);
			console.log("Los datos fueron cargados.");
			this.cargarDatosTienda();
		});
	}

	obtenerCategorias(){
		this.datos.listarCategorias()
		.subscribe(data => {
			this.lstCategorias = data;
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerVendedores(){
		this.datos.listarVendedores()
		.subscribe(data => {
			console.log(data[0]);
			this.lstVendedores = data;
			console.log("this.lstVendedores: "+this.lstVendedores);
			console.log("Los datos fueron cargados.");
		});
	}

	crearTienda(){
		let tienda = {};
		tienda["nombreTienda"] = this.nombreTienda;
		tienda["descripcion"] = this.descripcion;
		let svdUsuarios = {};
		svdUsuarios["id"] = this.idVendedor;
		tienda["svdUsuarios"] = svdUsuarios;
		let svdCategorias = {};
		svdCategorias["id"] = this.idCategoria;
		tienda["svdCategorias"] = svdCategorias;
		tienda["direccion"] = this.direccion;
		tienda["mapa"] = this.mapa;
		tienda["logo"] = this.logo;
		tienda["tienda"] = this.tienda;
		tienda["video"] = this.video;
		tienda["horarioAtencion"] = this.horarioAtencion;
		tienda["telefono"] = this.telefono;
		tienda["paginaWeb"] = this.paginaWeb;
		tienda["urlPaginaWeb"] = this.urlPaginaWeb;
		tienda["facebook"] = this.facebook;
		tienda["urlFacebook"] = this.urlFacebook;
		tienda["twitter"] = this.twitter;
		tienda["urlTwitter"] = this.urlTwitter;
		tienda["instagram"] = this.instagram;
		tienda["urlInstagram"] = this.urlInstagram;
		tienda["youtube"] = this.youtube;
		tienda["urlYoutube"] = this.urlYoutube;
		this.datos.crearTienda(tienda)
		.subscribe(data => {
			this.notifier.notify( 'msg-exito', 'Registro exitoso.' );
			console.log(data);
			if (this.idRol==4) {
				this.obtenerTiendas();
			}
			if (this.idRol==1) {
				this.obtenerTiendasPorIdVendedor();
			}
		}, err => {
			if (err.status==500) {
				this.notifier.notify( 'msg-error', 'Error en la operación.' );
			}
			if (err.status==406) {
				this.notifier.notify( 'msg-error', 'Error, el vendedor ya tiene tienda.' );
			}
			console.log("Error en la operación: "+err.status+" err.msg ");
		});
	}

	actualizarTienda(){
		let tienda = {};
		tienda["id"] = this.idTienda;
		tienda["nombreTienda"] = this.nombreTienda;
		tienda["descripcion"] = this.descripcion;
		let svdUsuarios = {}
		svdUsuarios["id"] = this.idVendedor;
		tienda["svdUsuarios"] = svdUsuarios;
		let svdCategorias = {};
		svdCategorias["id"] = this.idCategoria;
		tienda["svdCategorias"] = svdCategorias;
		tienda["direccion"] = this.direccion;
		tienda["mapa"] = this.mapa;
		tienda["logo"] = this.logo;
		tienda["tienda"] = this.tienda;
		tienda["video"] = this.video;
		tienda["horarioAtencion"] = this.horarioAtencion;
		tienda["telefono"] = this.telefono;
		tienda["paginaWeb"] = this.paginaWeb;
		tienda["urlPaginaWeb"] = this.urlPaginaWeb;
		tienda["facebook"] = this.facebook;
		tienda["urlFacebook"] = this.urlFacebook;
		tienda["twitter"] = this.twitter;
		tienda["urlTwitter"] = this.urlTwitter;
		tienda["instagram"] = this.instagram;
		tienda["urlInstagram"] = this.urlInstagram;
		tienda["youtube"] = this.youtube;
		tienda["urlYoutube"] = this.urlYoutube;
		this.datos.actualizarTienda(tienda)
		.subscribe(data => {
			this.notifier.notify( 'msg-exito', 'Actualización exitosa.' );
			console.log(data);
			if (this.idRol==4) {
				this.obtenerTiendas();
			}
			if (this.idRol==1) {
				this.obtenerTiendasPorIdVendedor();
			}
		}, err => {
			if (err.status==500) {
				this.notifier.notify( 'msg-error', 'Error en la operación.' );
			}
			if (err.status==406) {
				this.notifier.notify( 'msg-error', 'Error, no existe tienda.' );
			}
			console.log("Error en la operación: "+err.status+" err.msg ");
		});
	}

	actualizarInfoTienda(){
		let tienda = {};
		tienda["id"] = this.idTienda;
		tienda["nombreTienda"] = this.nombreTienda;
		tienda["descripcion"] = this.descripcion;
		let svdUsuarios = {}
		svdUsuarios["id"] = this.idVendedor;
		tienda["svdUsuarios"] = svdUsuarios;
		let svdCategorias = {};
		svdCategorias["id"] = this.idCategoria;
		tienda["svdCategorias"] = svdCategorias;
		tienda["direccion"] = this.direccion;
		tienda["mapa"] = this.mapa;
		//tienda["logo"] = this.logo;
		//tienda["tienda"] = this.tienda;
		tienda["video"] = this.video;
		tienda["horarioAtencion"] = this.horarioAtencion;
		tienda["telefono"] = this.telefono;
		tienda["paginaWeb"] = this.paginaWeb;
		tienda["urlPaginaWeb"] = this.urlPaginaWeb;
		tienda["facebook"] = this.facebook;
		tienda["urlFacebook"] = this.urlFacebook;
		tienda["twitter"] = this.twitter;
		tienda["urlTwitter"] = this.urlTwitter;
		tienda["instagram"] = this.instagram;
		tienda["urlInstagram"] = this.urlInstagram;
		tienda["youtube"] = this.youtube;
		tienda["urlYoutube"] = this.urlYoutube;
		this.datos.actualizarInfoTienda(tienda)
		.subscribe(data => {
			this.notifier.notify( 'msg-exito', 'Actualización exitosa.' );
			console.log(data);
			if (this.idRol==4) {
				this.obtenerTiendas();
			}
			if (this.idRol==1) {
				this.obtenerTiendasPorIdVendedor();
			}
		}, err => {
			if (err.status==500) {
				this.notifier.notify( 'msg-error', 'Error en la operación.' );
			}
			if (err.status==406) {
				this.notifier.notify( 'msg-error', 'Error, no existe tienda.' );
			}
			console.log("Error en la operación: "+err.status+" err.msg ");
		});
	}

	actualizarLogoTienda(){
		let tienda = {};
		tienda["id"] = this.idTienda;
		tienda["logo"] = this.logo;
		tienda["tienda"] = this.tienda;
		
		this.datos.actualizarLogoTienda(tienda)
		.subscribe(data => {
			this.notifier.notify( 'msg-exito', 'Actualización exitosa.' );
			console.log(data);
			if (this.idRol==4) {
				this.obtenerTiendas();
			}
			if (this.idRol==1) {
				this.obtenerTiendasPorIdVendedor();
			}
		}, err => {
			if (err.status==500) {
				this.notifier.notify( 'msg-error', 'Error en la operación.' );
			}
			if (err.status==406) {
				this.notifier.notify( 'msg-error', 'Error, no existe tienda.' );
			}
			console.log("Error en la operación: "+err.status+" err.msg ");
		});
	}


	eliminarTienda(){
		//this.cerrarModal();
		let tienda = {};
		tienda["id"] = this.idTienda;
		this.datos.eliminarTienda(tienda)
		.subscribe(data => {
			this.notifier.notify( 'msg-exito', 'Eliminación exitosa.' );
			console.log(data);
			this.obtenerTiendas();
		}, err => {
			if (err.status==500) {
				this.notifier.notify( 'msg-error', 'Error en la operación.' );
			}
			if (err.status==406) {
				this.notifier.notify( 'msg-error', 'Error, no existe tienda.' );
			}
			console.log("Error en la operación: "+err.status+" err.msg ");
		});
		
	}

	editarDatos(dato){
		this.idTienda = dato.id; //Id tienda
		this.nombreTienda = dato.nombreTienda;
		this.descripcion = dato.descripcion;
		this.idVendedor = dato.svdUsuarios.id;
		this.idCategoria = dato.svdCategorias.id;
		this.direccion = dato.direccion;
		this.mapa = dato.mapa;
		this.logo = dato.logo;
		this.tienda = dato.tienda;
		this.video = dato.video;
		this.horarioAtencion = dato.horarioAtencion;
		this.telefono = dato.telefono;
		this.paginaWeb = dato.paginaWeb;
		this.urlPaginaWeb = dato.urlPaginaWeb;
		this.facebook = dato.facebook;
		this.urlFacebook = dato.urlFacebook;
		this.twitter = dato.twitter;
		this.urlTwitter = dato.urlTwitter;
		this.instagram = dato.instagram;
		this.urlInstagram = dato.urlInstagram;
		this.youtube = dato.youtube;
		this.urlYoutube = dato.urlYoutube;
		this.mostrarFormulario=true;
		this.crud = 2;
		this.btnTitulo="Actualizar";
		this.medirNombreTiendaNum(event);
		this.medirDescripcionNum(event);
	}

	cargarDatosTienda(){
		this.idTienda = this.lstTiendas[0].id; //Id tienda
		this.nombreTienda = this.lstTiendas[0].nombreTienda;
		this.descripcion = this.lstTiendas[0].descripcion;
		this.idVendedor = this.lstTiendas[0].svdUsuarios.id;
		this.idCategoria = this.lstTiendas[0].svdCategorias.id;
		this.direccion = this.lstTiendas[0].direccion;
		this.mapa = this.lstTiendas[0].mapa;
		this.logo = this.lstTiendas[0].logo;
		this.tienda = this.lstTiendas[0].tienda;
		this.video = this.lstTiendas[0].video;
		this.horarioAtencion = this.lstTiendas[0].horarioAtencion;
		this.telefono = this.lstTiendas[0].telefono;
		this.paginaWeb = this.lstTiendas[0].paginaWeb;
		this.urlPaginaWeb = this.lstTiendas[0].urlPaginaWeb;
		this.facebook = this.lstTiendas[0].facebook;
		this.urlFacebook = this.lstTiendas[0].urlFacebook;
		this.twitter = this.lstTiendas[0].twitter;
		this.urlTwitter = this.lstTiendas[0].urlTwitter;
		this.instagram = this.lstTiendas[0].instagram;
		this.urlInstagram = this.lstTiendas[0].urlInstagram;
		this.youtube = this.lstTiendas[0].youtube;
		this.urlYoutube = this.lstTiendas[0].urlYoutube;
		this.mostrarFormulario=true;
		this.crud = 2;
		this.btnTitulo="Actualizar";
		this.medirNombreTiendaNum(event);
		this.medirDescripcionNum(event);
	}

	urlTienda(dato){
		this.router.navigateByUrl("/tienda/"+dato.id);
	}

	eliminarDatos(dato){
		this.idTienda = dato.id; //Id tienda
		this.eliminarTienda();
		//this.abrirModal();
		this.crud = 3;
	}

	btnGuardar(){
		if (this.crud==1) { //Registrar
			this.crearTienda();
		}
		if (this.crud==2) { //Actualizar
			
			if (this.idRol==4) {
				this.actualizarTienda();
			}
			if (this.idRol==1) {
				this.actualizarInfoTienda();
			}

		}
	}

	btnCancelar(){
		this.crud = 1;
		this.btnTitulo="Registrar";
		this.mostrarFormulario=false;
	}

	nuevaTienda(){
		this.mostrarFormulario=true;
		this.crud=1;
		this.btnTitulo="Registrar";
	}

	cargarArchivo(event,tipoImg) {
		if (event.target.files.length > 0) {
			let file = event.target.files[0];  
		  	this.archivo.push({ data: file, inProgress: false, progress: 0});
		  	this.archivo.forEach(file => {  
				this.subirArchivo(file,tipoImg);  
			});  
		}
	}

	subirArchivo(file,tipoImg) {  
		const formData = new FormData(); 
		//bytes 1.11mb = 1,169,051 bytes
		formData.append('uploadedFile', file.data);
		let extension;
		if (file.data.type=="image/jpeg") {
            extension = ".jpeg";
        }
        if (file.data.type=="image/png") {
            extension = ".png";
        }
		this.logo = "img-logo-tienda-"+this.idTienda+extension;
		this.tienda = "img-tienda-"+this.idTienda+extension;
		let fileNameImg = "";
		if (tipoImg=='img-logo-tienda') {
			fileNameImg = "img-logo-tienda-"+this.idTienda;
		}
		if (tipoImg=='img-tienda') {
			fileNameImg = "img-tienda-"+this.idTienda;
		}
		formData.append('fileName', fileNameImg);
		formData.append('fileType', file.data.type);
		formData.append('fileSize', file.data.size);
		file.inProgress = true;  
		this.datos.subirImgTienda(formData).subscribe(data => {
			this.archivo = [];
			console.log("se subió archivo.");
			this.notifier.notify( 'msg-exito', 'Archivo subido con éxito.' );
		}, err => {
			if (err.status==413) {
				file.inProgress = false;  
				console.log("Archivo muy pesado.");
				this.notifier.notify( 'msg-error', 'Error, archivo muy pesado (máx. 1mb).' );
			}
			if (err.status==406) {
				file.inProgress = false;  
				console.log("Tipo de archivo no permitido.");
				this.notifier.notify( 'msg-error', 'Error , solo se permite jpeg, jpg o png.' );
			}
			if (err.status==500) {
				file.inProgress = false;  
				console.log("ocurrió un eror.");
				this.notifier.notify( 'msg-error', 'Error con el archivo.' );
			}
		});
		//file.progress = Math.round(event.loaded * 100 / event.total);    
	}

	medirNombreTiendaNum(event){
		this.nombreTiendaNum = this.nombreTienda.length;
	}

	medirDescripcionNum(event){
		this.descripcionNum = this.descripcion.length;
	}

}
