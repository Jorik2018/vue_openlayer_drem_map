import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmtiendasComponent } from './admtiendas.component';

describe('AdmtiendasComponent', () => {
  let component: AdmtiendasComponent;
  let fixture: ComponentFixture<AdmtiendasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdmtiendasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdmtiendasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
