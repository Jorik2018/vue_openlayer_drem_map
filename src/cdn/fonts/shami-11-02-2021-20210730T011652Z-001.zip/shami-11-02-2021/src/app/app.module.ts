import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NotifierModule } from 'angular-notifier';

import { DsService } from './ds.service';
import { LoginGuard } from './login.guard';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PlantillaComponent } from './plantilla/plantilla.component';
import { CabeceraComponent } from './cabecera/cabecera.component';
import { PieComponent } from './pie/pie.component';
import { HtmlPipe } from './html.pipe';
import { InicioComponent } from './inicio/inicio.component';
import { DeseosComponent } from './deseos/deseos.component';
import { ProductosComponent } from './productos/productos.component';
import { ProductoComponent } from './producto/producto.component';
import { TiendasComponent } from './tiendas/tiendas.component';
import { TiendaComponent } from './tienda/tienda.component';
import { TerminosCondicionesComponent } from './terminos-condiciones/terminos-condiciones.component';
import { PedidosComponent } from './pedidos/pedidos.component';
import { CuentaComponent } from './cuenta/cuenta.component';
import { CarritoComponent } from './carrito/carrito.component';
import { AdmtiendasComponent } from './admtiendas/admtiendas.component';
import { AdmproductosComponent } from './admproductos/admproductos.component';
import { AdmpedidosComponent } from './admpedidos/admpedidos.component';
import { AdmusuariosComponent } from './admusuarios/admusuarios.component';
import { MenuadmComponent } from './menuadm/menuadm.component';
import { AdmconfigComponent } from './admconfig/admconfig.component';

@NgModule({
  declarations: [
    AppComponent,
    PlantillaComponent,
    CabeceraComponent,
    PieComponent,
    HtmlPipe,
    InicioComponent,
    DeseosComponent,
    ProductosComponent,
    ProductoComponent,
    TiendasComponent,
    TiendaComponent,
    TerminosCondicionesComponent,
    PedidosComponent,
    CuentaComponent,
    CarritoComponent,
    AdmtiendasComponent,
    AdmproductosComponent,
    AdmpedidosComponent,
    AdmusuariosComponent,
    MenuadmComponent,
    AdmconfigComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    NgbModule,
    FormsModule,
    HttpClientModule,
    NgxSpinnerModule,
    NotifierModule
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  providers: [DsService,LoginGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
