import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmconfigComponent } from './admconfig.component';

describe('AdmconfigComponent', () => {
  let component: AdmconfigComponent;
  let fixture: ComponentFixture<AdmconfigComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdmconfigComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdmconfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
