import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NotifierService } from 'angular-notifier';
import { AuthService } from '../auth.service';
import { DsService } from '../ds.service';

@Component({
	selector: 'app-admconfig',
	templateUrl: './admconfig.component.html',
	styleUrls: ['./admconfig.component.css']
})
export class AdmconfigComponent implements OnInit {

	lstConfiguracion;
	nombreSitioWeb;
	descripcionSitioWeb;
	url;

	constructor(private route: ActivatedRoute, private router: Router,
	private authService: AuthService, private notifier: NotifierService,
	private datos: DsService) { }

	ngOnInit(): void {
		this.obtenerConfiguracion();
	}

	obtenerConfiguracion(){
		this.datos.configuracion(1)
		.subscribe(data => {
			this.lstConfiguracion = data;
			this.nombreSitioWeb = data[0].nombreSitioWeb;
			this.descripcionSitioWeb = data[0].descripcionSitioWeb;
			this.url = data[0].url;
			console.log("Los datos fueron cargados.");
		});
	}

	actualizarConfiguracion(){
		let config = {};
		config["id"] = 1;
		config["nombreSitioWeb"] = this.nombreSitioWeb;
		config["descripcionSitioWeb"] = this.descripcionSitioWeb;
		config["url"] = this.url;
		this.datos.actualizarConfiguracion(config)
		.subscribe(data => {
			this.obtenerConfiguracion();
			this.notifier.notify( 'msg-exito', 'La información fue actualizada.' );
			console.log(data);
		}, err => {
			if (err.status==500) {
				this.notifier.notify( 'msg-error', 'Error en la operación.' );
			}
			if (err.status==406) {
				this.notifier.notify( 'msg-error', 'Error, no existe usuario.' );
			}
			console.log("Error en la operación: "+err.status);
		});
	}

}
