import { Injectable } from '@angular/core';
import { DsService } from './ds.service';
import { Router, ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { NotifierService } from 'angular-notifier';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

@Injectable({
	providedIn: 'root'
})
export class AuthService {
	saveuser;
	token;
	nombreUsuario;
	usuario;
	idUsuario;
	idPer;
	idRol;

	constructor(private route: ActivatedRoute, private router: Router, public datos:DsService,
		private spinner: NgxSpinnerService, public notifier: NotifierService,
		private modalService: NgbModal) { }

	obtenerAuth(usuario, clave){
		let datos = {};
		datos["usuario"] = usuario;
		datos["clave"] = clave;
		this.datos.getAuth(datos)
		.subscribe(data => {
			try{
				this.saveuser = data[0].usuario;
				if (usuario === this.saveuser && clave != null) {
					this.token = data[0].token;
					this.nombreUsuario = data[0].nombres;
					this.usuario = data[0].usuario;
					this.idUsuario = data[0].idUsuario;
					this.idPer = data[0].idPer;
					this.idRol = data[0].rol;
					sessionStorage.setItem('token', this.token);
					sessionStorage.setItem('nombreUsuario', this.nombreUsuario);
					sessionStorage.setItem('usuario', this.usuario);
					sessionStorage.setItem('idUsuario', this.idUsuario);
					sessionStorage.setItem('idPer', this.idPer);
					sessionStorage.setItem('idRol', this.idRol);
					this.spinner.show();
					setTimeout(() => {
						this.spinner.hide();
						this.modalService.dismissAll();
						this.router.navigateByUrl("/cuenta");
					}, 1000);
				} else {
					console.log("Error en las credenciales.");
					this.notifier.notify( 'msg-error', 'Error en las credenciales.' );
				}
			}
			catch(e){
				console.log(e);
				this.notifier.notify( 'msg-error', 'Error inesperado.' );
			}
		}, err => {
			console.log("Error en la conexión al servidor: "+err);
			this.notifier.notify( 'msg-peligro', 'Error en la conexión al servidor' );
		});
	}

	logout(){
		sessionStorage.removeItem('token');
		sessionStorage.removeItem('nombreUsuario');
		sessionStorage.removeItem('usuario');
		sessionStorage.removeItem('idUsuario');
		sessionStorage.removeItem('idPer');
		sessionStorage.removeItem('idRol');
	}

	getToken(){
		return sessionStorage.getItem('token');
	}

	getNombreUsuario(){
		return sessionStorage.getItem('nombreUsuario');
	}

	getUsuario(){
		return sessionStorage.getItem('usuario');
	}

	getIdUsuario(){
		return sessionStorage.getItem('idUsuario');
	}

	getIdPer(){
		return sessionStorage.getItem('idPer');
	}

	getIdRol(){
		return sessionStorage.getItem('idRol');
	}

	isLoggedIn(): boolean {
		return this.getToken() !== null;
	}

}
