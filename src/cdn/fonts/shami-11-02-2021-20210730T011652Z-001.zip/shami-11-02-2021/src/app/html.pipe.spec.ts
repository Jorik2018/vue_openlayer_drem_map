import { HtmlPipe } from './html.pipe';

describe('HtmlPipe', () => {
  it('create an instance', () => {
    const pipe = new HtmlPipe();
    expect(pipe).toBeTruthy();
  });
});
