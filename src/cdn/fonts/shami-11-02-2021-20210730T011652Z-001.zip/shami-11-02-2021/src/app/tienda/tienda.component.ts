import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DsService } from '../ds.service';
import { MetadataService } from '../metadata.service';

@Component({
	selector: 'app-tienda',
	templateUrl: './tienda.component.html',
	styleUrls: ['./tienda.component.css']
})
export class TiendaComponent implements OnInit {

	tiendaEspecifica;
	lstProductos;

	idTienda;
	nombreTienda;
	descripcion;
	logo;
	video;
	mapa;
	nombrePropietario;
	direccion;
	horarioAtencion;
	telefono;
	paginaWeb="www.web.com";
	urlPaginaWeb="";
	facebook="www.facebook.com";
	urlFacebook="";
	instagram="www.instagram.com";
	urlInstagram="";
	twitter="www.twitter.com";
	urlTwitter="";
	youtube="www.youtube.com";
	urlYoutube="";

	pagina=1;
	cantidad=4

	assetsImg;
	imgProducto;
	imgTienda;

	constructor(private route: ActivatedRoute, private router: Router, 
	private datos: DsService, private metadata: MetadataService) { }

	ngOnInit(): void {
		this.route.params.subscribe(params=>{
			this.idTienda = params['id'];
			this.obtenerProductosPorTiendaPaginados();
			console.log("params "+params['id']);
			let url = 'tienda/'+this.idTienda;
			this.metadata.updateTags('Tienda', url);
		})
		this.assetsImg = this.datos.getAssetsImg();
		this.imgProducto = this.datos.getImgProducto();
		this.imgTienda = this.datos.getImgTienda();
		this.obtenerTienda();
	}


	obtenerProductosPorTiendaPaginados(){
		this.datos.paginarProductosPorTienda(this.pagina,this.cantidad,this.idTienda)
		.subscribe(data => {
			this.lstProductos = data;
			console.log("Los datos fueron cargados.");
		});
	}

	verMasProductos(){
		this.pagina = this.pagina+1;
		this.datos.paginarProductosPorTienda(this.pagina,this.cantidad,this.idTienda)
		.subscribe(data => {
			if (data!=null) {
				this.lstProductos = this.lstProductos.concat(data);
			} else {

			}
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerTienda(){
		this.datos.tiendaEspecifica(this.idTienda)
		.subscribe(data => {
			this.tiendaEspecifica = data;
			this.nombreTienda = data['nombreTienda'];
			this.descripcion = data['descripcion'];
			this.logo = data['logo'];
			this.video = data['video'];
			this.mapa = data['mapa'];
			this.nombrePropietario = data['svdUsuarios'].svdPersona.nombres+' '+data['svdUsuarios'].svdPersona.apPaterno+
			' '+data['svdUsuarios'].svdPersona.apMaterno;
			this.direccion = data['direccion'];
			this.horarioAtencion = data['horarioAtencion'];
			this.telefono = data['telefono'];
			this.paginaWeb = data['paginaWeb'];
			this.urlPaginaWeb = data['urlPaginaWeb'];
			this.facebook = data['facebook'];
			this.urlFacebook = data['urlFacebook'];
			this.instagram = data['instagram'];
			this.urlInstagram = data['urlInstagram'];
			this.twitter = data['twitter'];
			this.urlTwitter = data['urlTwitter'];
			this.youtube = data['youtube'];
			this.urlYoutube = data['urlYoutube'];
			console.log("Los datos fueron cargados.");
		});
	}

	irProducto(dato){
		this.router.navigateByUrl("/producto/"+dato.idProducto);
	}

}
