import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DsService {

  	baseAPI = "http://localhost:8181"; //https://web.regionancash.gob.pe http://localhost:8181
	url = this.baseAPI+"/apishami/api";
	imgPerfil = this.url+"/archivos/imgperfil/";
	imgProducto = this.url+"/archivos/imgproducto/";
	imgTienda = this.url+"/archivos/imgtienda/";
	imgCategoria = this.url+"/archivos/imgcategoria/";

	baseCliente = "http://localhost:4200"; //https://ancashshami.pe http://localhost:4200
	web = this.baseCliente+""; // /shami
	assets = this.web+"/assets";
	assetsImg = this.assets+"/img/";
	assetPdf = this.assets+"/pdf/";

	constructor(private http: HttpClient) { }

	/** BASE URL API */

	getBaseAPI(){
		return this.baseAPI;
	}

	getUrl(){
		return this.url;
	}

	getAssetsImg(){
		return this.assetsImg;
	}

	getImgPerfil(){
		return this.imgPerfil;
	}

	getImgProducto(){
		return this.imgProducto;
	}

	getImgTienda(){
		return this.imgTienda;
	}

	getImgCategoria(){
		return this.imgCategoria;
	}

	getAuth(datos){
		return this.http.post(this.url+'/token/authtoken/',datos);
	}

	crearCuenta(usuario){
		return this.http.post(this.url+'/usuarios/crearcuenta/',usuario);
	}

	crearCuentaVendedor(usuario){
		return this.http.post(this.url+'/usuarios/crearcuentavendedor/',usuario);
	}

	enviarCorreoRecuperacion(correo){
		return this.http.get(this.url+'/usuarios/enviarcorreo/'+correo);
	}

	datosPersonaPorId(id){
		return this.http.get(this.url+'/persona/datos/'+id);
	}

	rolUsuarioPorIdPer(idPer){
		return this.http.get(this.url+'/usuarios/rol/'+idPer);
	}

	traerIdUsuarioPorIdPer(idPer){
		return this.http.get(this.url+'/usuarios/idusuario/'+idPer);
	}

	listarRoles(){
		return this.http.get(this.url+'/usuarios/roles');
	}

	listarUsuarios(){
		return this.http.get(this.url+'/usuarios/listar');
	}

	crearUsuario(usuario){
		return this.http.post(this.url+'/usuarios/crear/',usuario);
	}

	actualizarUsuario(usuario){
		return this.http.post(this.url+'/usuarios/actualizar/',usuario);
	}

	eliminarUsuario(usuario){
		return this.http.post(this.url+'/usuarios/eliminar/',usuario);
	}

	habilitacionUsuario(usuario){
		return this.http.post(this.url+'/usuarios/habilitacion/',usuario);
	}

	resetearClaveUsuario(usuario){
		return this.http.post(this.url+'/usuarios/resetear/',usuario);
	}

	cambiarInfoContacto(usuario){
		return this.http.post(this.url+'/usuarios/cambiarinfocontacto/',usuario);
	}

	cambiarInfoDireccion(usuario){
		return this.http.post(this.url+'/usuarios/cambiarinfodireccion/',usuario);
	}

	cambiarClave(usuario){
		return this.http.post(this.url+'/usuarios/cambiarclave/',usuario);
	}

	listarVendedores(){
		return this.http.get(this.url+'/usuarios/listarvendedores');
	}

	listarRepartidores(){
		return this.http.get(this.url+'/usuarios/listarrepartidores');
	}

	listarCompradores(){
		return this.http.get(this.url+'/usuarios/listarcompradores');
	}

	listarAdministradores(){
		return this.http.get(this.url+'/usuarios/listaradministradores');
	}

	buscarUsuarioApellido(apellido){
		return this.http.get(this.url+'/usuarios/buscarapellido/'+apellido);
	}

	listarDistritos(idDpto,idProv){
		return this.http.get(this.url+'/departamento/distritos/'+idDpto+'/'+idProv);
	}

	listarProvincias(id){
		return this.http.get(this.url+'/departamento/provincias/'+id);
	}

	listarDepartamentos(){
		return this.http.get(this.url+'/departamento/departamentos');
	}

	listarTiendas(){
		return this.http.get(this.url+'/tienda/listar');
	}

	paginarTiendas(pag,cant){
		return this.http.get(this.url+'/tienda/paginador/'+pag+'/'+cant);
	}

	paginarTiendasPorCategoria(pag,cant,id){
		return this.http.get(this.url+'/tienda/paginadoporcategoria/'+pag+'/'+cant+'/'+id);
	}

	listarBuscarTiendaPorNombre(nombre){
		return this.http.get(this.url+'/tienda/buscartienda/'+nombre);
	}

	listarTiendasPorIdVendedor(id){
		return this.http.get(this.url+'/tienda/listarporvendedor/'+id);
	}

	tiendaEspecifica(id){
		return this.http.get(this.url+'/tienda/tiendaespecifica/'+id);
	}

	crearTienda(tienda){
		return this.http.post(this.url+'/tienda/crear/',tienda);
	}

	actualizarTienda(tienda){
		return this.http.post(this.url+'/tienda/actualizar/',tienda);
	}

	actualizarInfoTienda(tienda){
		return this.http.post(this.url+'/tienda/actualizarinfotienda/',tienda);
	}

	actualizarLogoTienda(tienda){
		return this.http.post(this.url+'/tienda/actualizarlogotienda/',tienda);
	}

	eliminarTienda(tienda){
		return this.http.post(this.url+'/tienda/eliminar/',tienda);
	}

	/* PRODUCTOS */

	listarProductos(){
		return this.http.get(this.url+'/producto/listar');
	}

	paginarProductos(pag,cant){
		return this.http.get(this.url+'/producto/paginador/'+pag+'/'+cant);
	}

	paginarProductosRecientes(pag,cant){
		return this.http.get(this.url+'/producto/paginadorultimos/'+pag+'/'+cant);
	}

	paginarProductosPorCategoria(pag,cant,id){
		return this.http.get(this.url+'/producto/paginadoporcategoria/'+pag+'/'+cant+'/'+id);
	}

	paginarProductosPorSubcategoria(pag,cant,id){
		return this.http.get(this.url+'/producto/paginadoporsubcategoria/'+pag+'/'+cant+'/'+id);
	}

	paginarProductosPorTienda(pag,cant,id){
		return this.http.get(this.url+'/producto/paginadoportienda/'+pag+'/'+cant+'/'+id);
	}

	listarProductosPorIdVendedor(id){
		return this.http.get(this.url+'/producto/listarporvendedor/'+id);
	}

	listarBuscarProductoPorNombre(nombre){
		return this.http.get(this.url+'/producto/buscarproducto/'+nombre);
	}

	productoEspecifico(id){
		return this.http.get(this.url+'/producto/productoespecifico/'+id);
	}

	crearProducto(producto){
		return this.http.post(this.url+'/producto/crear/',producto);
	}

	actualizarProducto(producto){
		return this.http.post(this.url+'/producto/actualizar/',producto);
	}

	eliminarProducto(producto){
		return this.http.post(this.url+'/producto/eliminar/',producto);
	}

	/* CATEGORÍAS - SUBCATEGORÍAS */

	listarCategorias(){
		return this.http.get(this.url+'/categorias/listar');
	}

	listarCategoriaPorId(id){
		return this.http.get(this.url+'/categorias/listar/'+id);
	}

	listarSubcategorias(){
		return this.http.get(this.url+'/subcategorias/listar');
	}

	listarSubcategoriasPorCategorias(id){
		return this.http.get(this.url+'/subcategorias/porcategoria/'+id);
	}

	/* LISTA DE DESEOS */

	listarDeseos(id){
		return this.http.get(this.url+'/deseos/'+id);
	}

	paginarDeseosPorComprador(pag,cant,id){
		return this.http.get(this.url+'/deseos/paginadoporcomprador/'+pag+'/'+cant+'/'+id);
	}

	crearDeseo(deseo){
		return this.http.post(this.url+'/deseos/crear/',deseo);
	}

	eliminarDeseo(deseo){
		return this.http.post(this.url+'/deseos/eliminar/',deseo);
	}

	listarProductosEnCarritoPorIdComprador(id){
		return this.http.get(this.url+'/orden/listarcarrito/'+id);
	}

	crearCarrito(carrito){
		return this.http.post(this.url+'/orden/crearcarrito/',carrito);
	}

	actualizarCarrito(carrito){
		return this.http.post(this.url+'/orden/actualizarcarrito/',carrito);
	}

	eliminarCarrito(carrito){
		return this.http.post(this.url+'/orden/eliminarcarrito/',carrito);
	}

	ordenarProducto(orden){
		return this.http.post(this.url+'/orden/ordenarproducto/',orden);
	}

	listarPedidosPorIdComprador(id){
		return this.http.get(this.url+'/orden/listarorden/'+id);
	}

	listarPedidosPorIdVendedor(id){
		return this.http.get(this.url+'/orden/listarordenporvendedor/'+id);
	}

	listarTodosLosPedidos(){
		return this.http.get(this.url+'/orden/listartodo/');
	}

	listarEnviosPorIdVendedor(id){
		return this.http.get(this.url+'/orden/listarenviosporrepartidor/'+id);
	}

	atenderPedido(orden){
		return this.http.post(this.url+'/orden/atenderpedido/',orden);
	}

	asignarRepartidor(envio){
		return this.http.post(this.url+'/orden/asignarrepartidor/',envio);
	}

	confirmarEntregaPedido(envio){
		return this.http.post(this.url+'/orden/confirmarentregapedido/',envio);
	}

	configuracion(id){
		return this.http.get(this.url+'/configuracion/configuracion/'+id);
	}

	actualizarConfiguracion(config){
		return this.http.post(this.url+'/configuracion/atualizar/',config);
	}

	subirImgPerfil(archivo){
		return this.http.post(this.url+'/archivos/perfiles',archivo);
	}

	subirImgTienda(archivo){
		return this.http.post(this.url+'/archivos/tiendas',archivo);
	}

	subirImgProducto(archivo){
		return this.http.post(this.url+'/archivos/productos',archivo);
	}

}
