import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DsService } from '../ds.service';
import { MetadataService } from '../metadata.service';

@Component({
	selector: 'app-tiendas',
	templateUrl: './tiendas.component.html',
	styleUrls: ['./tiendas.component.css']
})
export class TiendasComponent implements OnInit {

	lstCategorias;
	lstTiendas;

	pagina=1;
	cantidad=4;

	assetsImg;
	imgProducto;
	imgTienda;
	imgCategoria;

	paginaCategoria=1;
	cantidadCategoria=8;
	idCategoria=1;

	buscarPalabra;
	lstResultadosBusqueda;
	encontraronResultados=true;

	constructor(private route: ActivatedRoute, private router: Router, 
	private datos: DsService, private metadata: MetadataService) { }

	ngOnInit(): void {
		this.route.params.subscribe(params=>{
			this.idCategoria = params['id'];
			this.obtenerTiendasPorCategoriaPaginadas();
			console.log("params "+params['id']);
			let url = 'tiendas/'+this.idCategoria;
			this.metadata.updateTags('Tiendas', url);
		})
		this.assetsImg = this.datos.getAssetsImg();
		this.imgProducto = this.datos.getImgProducto();
		this.imgTienda = this.datos.getImgTienda();
		this.imgCategoria = this.datos.getImgCategoria();
		this.obtenerCategorias();
	}

	obtenerCategorias(){
		this.datos.listarCategorias()
		.subscribe(data => {
			this.lstCategorias = data;
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerTiendasPaginadas(){
		this.datos.paginarTiendas(this.pagina,this.cantidad)
		.subscribe(data => {
			this.lstTiendas = data;
			console.log("Los datos fueron cargados.");
		});
	}

	verMasTiendas(){
		this.pagina = this.pagina+1;
		this.datos.paginarTiendas(this.pagina,this.cantidad)
		.subscribe(data => {
			if (data!=null) {
				this.lstTiendas = this.lstTiendas.concat(data);
			} else {

			}
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerTiendasPorCategoriaPaginadas(){
		this.datos.paginarTiendasPorCategoria(this.paginaCategoria,this.cantidadCategoria,this.idCategoria)
		.subscribe(data => {
			this.lstTiendas = data;
			console.log("Los datos fueron cargados.");
		});
	}

	verMasTiendasPorCategoria(){
		this.paginaCategoria = this.paginaCategoria+1;
		this.datos.paginarTiendasPorCategoria(this.paginaCategoria,this.cantidadCategoria,this.idCategoria)
		.subscribe(data => {
			if (data!=null) {
				this.lstTiendas = this.lstTiendas.concat(data);
			} else {

			}
			console.log("Los datos fueron cargados.");
		});
	}

	traerlistaBuscarTiendaPorNombre(){
        this.datos.listarBuscarTiendaPorNombre(this.buscarPalabra)
            .subscribe(data => {
                //this.notifier.notify( 'msg-exito', 'Registro exitoso.' );
                this.lstResultadosBusqueda = data;
                this.lstTiendas = data;
                let resultados = 0;
                resultados = this.lstResultadosBusqueda.length;
                if (resultados>0) {
                	this.encontraronResultados=true;
                    //this.mostrarResultados = "abierto";
                    //this.notifier.notify( 'msg-exito', 'Se encontraron resultados.' );
                } else {
                	this.encontraronResultados=false;
                    //this.mostrarResultados = "";
                    //this.notifier.notify( 'msg-error', 'No se encontraron resultados.' );
                }
            }, err => {
                if (err.status==500) {
                	this.encontraronResultados=false;
                    //this.mostrarResultados = "";
                    //this.notifier.notify( 'msg-error', 'No se encontraron resultados.' );
                }
            });
    }

	cargarPorCategoria(dato){
		this.router.navigateByUrl("/tiendas/"+dato.id);
		this.idCategoria = dato.id;
	}

	irTienda(dato){
		this.router.navigateByUrl("/tienda/"+dato.id);
	}

}
