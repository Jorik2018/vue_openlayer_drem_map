import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NotifierService } from 'angular-notifier';
import { AuthService } from '../auth.service';
import { DsService } from '../ds.service';

@Component({
	selector: 'app-cuenta',
	templateUrl: './cuenta.component.html',
	styleUrls: ['./cuenta.component.css']
})
export class CuentaComponent implements OnInit {

	datosPersona;
	nombres;
	apPaterno;
	apMaterno;
	sexo;
	dni;
	fechaNacimiento;
	correo;
	telefono;
	celular;
	codigoPostal;
	urbanizacion;
	sector;
	manzana;
	lote;
	departamento;
	provincia;
	distrito;
	idDep;
	idProv;
	idDist;
	urlPerfil;
	pais="Perú";
	idUsuario;
	activarInfoContacto=false;
	activarInfoDireccion=false;
	lstDepartamentos;
	lstProvincias;
	lstDistritos;
	idPer;
	claveAnterior;
	claveNueva;
	repetirClaveNueva;

	imgPerfil;
	archivo = [];

	assetsImg;
	progreso=0;
	enProgreso=false;

	constructor(private route: ActivatedRoute, private router: Router,
	private authService: AuthService, private notifier: NotifierService,
	private datos: DsService) { }

	ngOnInit(): void {
		this.imgPerfil = this.datos.getImgPerfil();
		this.idPer = this.authService.getIdPer();
		this.idUsuario = this.authService.getIdUsuario();
		this.traerDatosPersonaPorId();
		this.obtenerDepartamentos();
		this.assetsImg = this.datos.getAssetsImg();
	}

	onChangeDepartamento(obj){
		let objeto = JSON.parse(obj);
		console.log("entries: "+Object.entries(objeto));
		this.idDep = objeto.svdDepartamentoPK.idDpto;
		this.departamento = objeto.nombreDpto;
		this.obtenerProvincias(this.idDep);
	}

	onChangeProvincia(obj){
		let objeto = JSON.parse(obj);
		console.log("entries: "+Object.entries(objeto));
		this.idProv = objeto.svdProvinciaPK.idProv;
		this.provincia = objeto.nombreProv;
		this.obtenerDistritos(this.idDep,this.idProv);
	}

	onChangeDistrito(obj){
		let objeto = JSON.parse(obj);
		console.log("entries: "+Object.entries(objeto));
		this.distrito = objeto.nombreDist;
	}

	obtenerDepartamentos(){
		this.datos.listarDepartamentos()
		.subscribe(data => {
			this.lstDepartamentos = data;
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerProvincias(idDep){
		this.datos.listarProvincias(idDep)
		.subscribe(data => {
			this.lstProvincias = data;
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerDistritos(idDep,idProv){
		this.datos.listarDistritos(idDep,idProv)
		.subscribe(data => {
			this.lstDistritos = data;
			console.log("Los datos fueron cargados.");
		});
	}

	abrirInfoContacto(){
		this.activarInfoContacto=true;
	}

	cerrarInfoContacto(){
		this.activarInfoContacto=false;
	}

	abrirInfoDireccion(){
		this.activarInfoDireccion=true;
	}

	cerrarInfoDireccion(){
		this.activarInfoDireccion=false;
	}

	traerDatosPersonaPorId(){
		
		if (this.idPer==null) {
			this.notifier.notify( 'msg-error', 'Usted debe estar logueado.' );
		} else {
			this.datos.datosPersonaPorId(this.idPer)
			.subscribe(data => {
				this.datosPersona = data;
				this.nombres = data['nombres'];
				this.apPaterno = data['apPaterno'];
				this.apMaterno = data['apMaterno'];
				this.urlPerfil = data['urlPerfil'];
				this.sexo = data['sexo'];
				this.dni = data['dni'];
				this.fechaNacimiento = data['fechaNacimiento'];
				this.correo = data['correo'];
				this.telefono = data['telefono'];
				this.celular = data['celular'];
				this.codigoPostal = data['codigoPostal'];
				this.urbanizacion = data['urbanizacion'];
				this.sector = data['sector'];
				this.manzana = data['manzana'];
				this.lote = data['lote'];
				this.departamento = data['departamento'];
				this.provincia = data['provincia'];
				this.distrito = data['distrito'];
				this.obtenerDepartamentos();
				this.idDep = data['idDep'];
				this.obtenerProvincias(this.idDep);
				this.idProv = data['idProv'];
				this.obtenerDistritos(this.idDep,this.idProv);
				this.idDist = data['idDist'];
			}, err => {
				if (err.status==500) {
					this.notifier.notify( 'msg-error', 'Error al traer los datos.' );
				}
				console.log("Error en la operación: "+err.status);
			});
		}
		
	}

	actualizarInfoContacto(){
		let usuario = {};
		usuario["id"] = this.idUsuario;
		let svdPersona = {};
		svdPersona["idPer"] = this.idPer;
		svdPersona["nombres"] = this.nombres;
		svdPersona["apPaterno"] = this.apPaterno;
		svdPersona["apMaterno"] = this.apMaterno;
		svdPersona["urlPerfil"] = this.urlPerfil;
		svdPersona["sexo"] = this.sexo;
		svdPersona["dni"] = this.dni;
		svdPersona["fechaNacimiento"] = this.fechaNacimiento;
		svdPersona["correo"] = this.correo;
		svdPersona["celular"] = this.celular;
		usuario["svdPersona"] = svdPersona;
		this.datos.cambiarInfoContacto(usuario)
		.subscribe(data => {
			this.traerDatosPersonaPorId();
			this.notifier.notify( 'msg-exito', 'La información fue actualizada.' );
			console.log(data);
			this.cerrarInfoContacto();
		}, err => {
			if (err.status==500) {
				this.notifier.notify( 'msg-error', 'Error en la operación.' );
			}
			if (err.status==406) {
				this.notifier.notify( 'msg-error', 'Error, no existe usuario.' );
			}
			console.log("Error en la operación: "+err.status);
		});
	}

	actualizarInfoDireccion(){
		let usuario = {};
		usuario["id"] = this.idUsuario;
		let svdPersona = {};
		svdPersona["idPer"] = this.idPer;
		svdPersona["codigoPostal"] = this.codigoPostal;
		svdPersona["urbanizacion"] = this.urbanizacion;
		svdPersona["sector"] = this.sector;
		svdPersona["manzana"] = this.manzana;
		svdPersona["lote"] = this.lote;
		svdPersona["departamento"] = this.departamento;
		svdPersona["provincia"] = this.provincia;
		svdPersona["distrito"] = this.distrito;
		svdPersona["celular"] = this.celular;
		usuario["svdPersona"] = svdPersona;
		this.datos.cambiarInfoDireccion(usuario)
		.subscribe(data => {
			this.traerDatosPersonaPorId();
			this.notifier.notify( 'msg-exito', 'La información fue actualizada.' );
			console.log(data);
			this.cerrarInfoDireccion();
		}, err => {
			if (err.status==500) {
				this.notifier.notify( 'msg-error', 'Error en la operación.' );
			}
			if (err.status==406) {
				this.notifier.notify( 'msg-error', 'Error, no existe usuario.' );
			}
			console.log("Error en la operación: "+err.status+" err.msg ");
		});
	}

	actualizarClave(){
		let cambio = {};
		let svdUsuarios = {};
		cambio["svdUsuarios"] = svdUsuarios;
		cambio["claveNueva"] = this.claveNueva;
		svdUsuarios["usuario"] = this.correo;
		svdUsuarios["clave"] = this.claveAnterior;
		this.datos.cambiarClave(cambio)
		.subscribe(data => {
			this.traerDatosPersonaPorId();
			this.notifier.notify( 'msg-exito', 'La clave fue actualizada.' );
			console.log(data);
			this.cerrarInfoDireccion();
		}, err => {
			if (err.status==500) {
				this.notifier.notify( 'msg-error', 'Error en la operación.' );
			}
			if (err.status==406) {
				this.notifier.notify( 'msg-error', 'Error, credenciales inválidas.' );
			}
			console.log("Error en la operación: "+err.status+" err.msg ");
		});
	}

	validarCorreo(correo){
 		if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(correo)){
    		return true;
  		}
    	return false;
	}

	validarClave(clave){
		let strClave = clave+"";
 		if (strClave.length<=30 && strClave.length>=8){
    		return true;
  		}
    	return false;
	}

	validarRepetirClave(clave,repetirClave){
		if (clave==repetirClave) {
			return true;
		} 
		return false;
	}

	cargarArchivo(event) {
		if (event.target.files.length > 0) {
			let file = event.target.files[0];  
		  	this.archivo.push({ data: file, inProgress: false, progress: 0});
		  	this.archivo.forEach(file => {
		  		console.log("***file: "+file)  ;
				this.subirArchivo(file);  
			});  
		}
	}

	subirArchivo(file) {  
		const formData = new FormData(); 
		//bytes 1.11mb = 1,169,051 bytes
		formData.append('uploadedFile', file.data);
		let extension;
		if (file.data.type=="image/jpeg") {
            extension = ".jpeg";
        }
        if (file.data.type=="image/png") {
            extension = ".png";
        }
		this.urlPerfil = "img-perfil-"+this.idPer+extension;
		formData.append('fileName', "img-perfil-"+this.idPer);
		formData.append('fileType', file.data.type);
		formData.append('fileSize', file.data.size);
		file.inProgress = true;  
		this.datos.subirImgPerfil(formData).subscribe(data => {
			this.archivo = [];
			this.enProgreso=true;
			console.log("se subió archivo.");
			this.notifier.notify( 'msg-exito', 'Archivo subido con éxito.' );
			},
	      	err => {
				if (err.status==413) {
					file.inProgress = false;  
					console.log("Archivo muy pesado.");
					this.notifier.notify( 'msg-error', 'Error, archivo muy pesado (máx. 1mb).' );
				}
				if (err.status==406) {
					file.inProgress = false;  
					console.log("Tipo de archivo no permitido.");
					this.notifier.notify( 'msg-error', 'Error , solo se permite jpeg, jpg o png.' );
				}
				if (err.status==500) {
					file.inProgress = false;  
					console.log("ocurrió un eror.");
					this.notifier.notify( 'msg-error', 'Error con el archivo.' );
				}
			});
			//file.progress = Math.round(event.loaded * 100 / event.total);    
	}

}
