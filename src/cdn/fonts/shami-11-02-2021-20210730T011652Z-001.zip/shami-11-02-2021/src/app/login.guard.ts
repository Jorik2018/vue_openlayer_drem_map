import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';
import { Router, ActivatedRoute } from '@angular/router';
import { DsService } from './ds.service';

@Injectable({
  providedIn: 'root'
})
export class LoginGuard implements CanActivate {
	/*
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    return true;
  }
  */
  url;

  constructor(private authService: AuthService, private router: Router, 
    private ruta: ActivatedRoute, public datos: DsService) {
  	//this.redireccionar();
  }
  
  canActivate(route: ActivatedRouteSnapshot): boolean {
    //console.log('canActivate()');
    //console.log("canAtivate() "+this.authService.isLoggedIn());
    if (!this.authService.isLoggedIn()) {
      this.router.navigateByUrl("/inicio");
    }

    this.url=route.url.join('');
    if (this.url=="admcuenta" || this.url=="admconfig" || 
      this.url=="admpedidos" || this.url=="admproductos" ||
      this.url=="admtiendas" || this.url=="admusuarios") {
      if (this.authService.getIdRol()=="3") {
        this.router.navigateByUrl("/inicio");
      }
    }

    if (this.url=="admconfig") {
      if (this.authService.getIdRol()=="1") {
        this.router.navigateByUrl("/inicio");
      }
    }

    if (this.url=="admconfig" || this.url=="admproductos" ||
      this.url=="admtiendas" || this.url=="admusuarios") {
      if (this.authService.getIdRol()=="2") {
        this.router.navigateByUrl("/inicio");
      }
    }

    return this.authService.isLoggedIn();
  }

}
