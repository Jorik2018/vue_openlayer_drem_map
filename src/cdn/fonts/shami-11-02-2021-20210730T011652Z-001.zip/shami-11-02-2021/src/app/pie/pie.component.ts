import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DsService } from '../ds.service';

@Component({
	selector: 'pie',
	templateUrl: './pie.component.html',
	styleUrls: ['./pie.component.css']
})
export class PieComponent implements OnInit {

	assetsImg;

	constructor(private route: ActivatedRoute, 
		private router: Router, private datos: DsService) { }

	ngOnInit(): void {
		this.assetsImg = this.datos.getAssetsImg();
	}

	irTerminosCondiciones(){
		this.router.navigateByUrl("/terminos-condiciones");
	}

}
