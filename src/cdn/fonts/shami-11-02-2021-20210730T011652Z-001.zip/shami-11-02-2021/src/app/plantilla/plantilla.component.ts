import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plantilla',
  templateUrl: './plantilla.component.html',
  styleUrls: ['./plantilla.component.css']
})
export class PlantillaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
