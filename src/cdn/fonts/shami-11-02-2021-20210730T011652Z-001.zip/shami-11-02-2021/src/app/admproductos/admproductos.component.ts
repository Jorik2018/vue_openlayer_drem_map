import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NotifierService } from 'angular-notifier';
import { AuthService } from '../auth.service';
import { DsService } from '../ds.service';

@Component({
	selector: 'app-admproductos',
	templateUrl: './admproductos.component.html',
	styleUrls: ['./admproductos.component.css']
})
export class AdmproductosComponent implements OnInit {

	lstProductos;
	lstTiendas;
	lstSubcategorias;
	idTienda;
	idSubcategoria;
	idProducto;
	nombreProducto="";
	descripcion="";
	urlImagen="-";
	urlImagenA="-";
	urlImagenB="-";
	urlImagenC="-";
	stock=1;
	precio;
	dimensiones="-";
	peso="-";
	demoraEnvio="-";
	mostrarFormulario=false;
	btnTitulo="Registrar";
	crud=0;
	modal="";
	idRol;
	idUsuario;

	archivo = [];

	nombreProductoNum=0;
	descripcionNum=0;

	constructor(private route: ActivatedRoute, private router: Router,
		private authService: AuthService, private notifier: NotifierService,
		private datos: DsService) { }

	ngOnInit(): void {
		this.idRol = parseInt(this.authService.getIdRol());
		this.idUsuario = parseInt(this.authService.getIdUsuario());
		if (this.idRol==4) {
			this.obtenerProductos();
			this.obtenerTiendas();
			this.obtenerSubcategorias();
		}
		if (this.idRol==1) {
			this.obtenerProductosPorIdVendedor();
			this.obtenerSubcategorias();
			this.obtenerTiendasPorIdVendedor();
			//this.idVendedor = this.idUsuario;
		}
	}

	medirNombreProductoNum(event){
		//const inputChar = String.fromCharCode(event.charCode);
		//console.log("inputChar: "+inputChar);
		this.nombreProductoNum = this.nombreProducto.length;
	}

	medirDescripcionNum(event){
		this.descripcionNum = this.descripcion.length;
	}

	obtenerProductos(){
		this.datos.listarProductos()
		.subscribe(data => {
			//console.log(data[0]);
			this.lstProductos = data;
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerProductosPorIdVendedor(){
		this.datos.listarProductosPorIdVendedor(this.idUsuario)
		.subscribe(data => {
			console.log(data[0]);
			this.lstProductos = data;
			this.idTienda = data[0].svdTienda.id;
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerTiendas(){
		this.datos.listarTiendas()
		.subscribe(data => {
			//console.log(data[0]);
			this.lstTiendas = data;
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerTiendasPorIdVendedor(){
		this.datos.listarTiendasPorIdVendedor(this.idUsuario)
		.subscribe(data => {
			this.lstTiendas = data;
			this.idTienda = data[0].id;
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerSubcategorias(){
		this.datos.listarSubcategorias()
		.subscribe(data => {
			//console.log(data[0]);
			this.lstSubcategorias = data;
			console.log("Los datos fueron cargados.");
		});
	}
	
	crearProducto(){
		let producto = {};
		producto["nombreProducto"] = this.nombreProducto;
		producto["descripcion"] = this.descripcion;
		producto["urlImagen"] = this.urlImagen;
		producto["urlImagenA"] = this.urlImagenA;
		producto["urlImagenB"] = this.urlImagenB;
		producto["urlImagenC"] = this.urlImagenC;
		producto["stock"] = this.stock;
		producto["precio"] = this.precio;
		producto["dimensiones"] = this.dimensiones;
		producto["peso"] = this.peso;
		producto["demoraEnvio"] = this.demoraEnvio;
		let svdTienda = {}
		svdTienda["id"] = this.idTienda;
		producto["svdTienda"] = svdTienda;
		let svdSubcategorias = {}
		svdSubcategorias["id"] = this.idSubcategoria;
		producto["svdSubcategorias"] = svdSubcategorias;
		this.datos.crearProducto(producto)
		.subscribe(data => {
			this.notifier.notify( 'msg-exito', 'Registro exitoso.' );
			console.log(data);
			if (this.idRol==4) {
				this.obtenerProductos();
			}
			if (this.idRol==1) {
				this.obtenerProductosPorIdVendedor();
			}
		}, err => {
			if (err.status==500) {
				this.notifier.notify( 'msg-error', 'Error en la operación.' );
			}
			console.log("Error en la operación: "+err.status+" err.msg ");
		});
	}

	actualizarProducto(){
		let producto = {};
		producto["idProducto"] = this.idProducto;
		producto["nombreProducto"] = this.nombreProducto;
		producto["descripcion"] = this.descripcion;
		producto["urlImagen"] = this.urlImagen;
		producto["urlImagenA"] = this.urlImagenA;
		producto["urlImagenB"] = this.urlImagenB;
		producto["urlImagenC"] = this.urlImagenC;
		producto["stock"] = this.stock;
		producto["precio"] = this.precio;
		producto["dimensiones"] = this.dimensiones;
		producto["peso"] = this.peso;
		producto["demoraEnvio"] = this.demoraEnvio;
		let svdTienda = {}
		svdTienda["id"] = this.idTienda;
		producto["svdTienda"] = svdTienda;
		let svdSubcategorias = {}
		svdSubcategorias["id"] = this.idSubcategoria;
		producto["svdSubcategorias"] = svdSubcategorias;
		this.datos.actualizarProducto(producto)
		.subscribe(data => {
			this.notifier.notify( 'msg-exito', 'Actualización exitosa.' );
			console.log(data);
			if (this.idRol==4) {
				this.obtenerProductos();
			}
			if (this.idRol==1) {
				this.obtenerProductosPorIdVendedor();
			}
		}, err => {
			if (err.status==500) {
				this.notifier.notify( 'msg-error', 'Error en la operación.' );
			}
			if (err.status==406) {
				this.notifier.notify( 'msg-error', 'Error, no existe producto.' );
			}
			console.log("Error en la operación: "+err.status+" err.msg ");
		});
	}


	eliminarProducto(){
		//this.cerrarModal();
		let producto = {};
		producto["idProducto"] = this.idProducto;
		this.datos.eliminarProducto(producto)
		.subscribe(data => {
			this.notifier.notify( 'msg-exito', 'Eliminación exitosa.' );
			console.log(data);
			this.obtenerProductos();
		}, err => {
			if (err.status==500) {
				this.notifier.notify( 'msg-error', 'Error en la operación.' );
			}
			if (err.status==406) {
				this.notifier.notify( 'msg-error', 'Error, no existe producto.' );
			}
			console.log("Error en la operación: "+err.status+" err.msg ");
		});
		
	}

	editarDatos(dato){
		this.idTienda = dato.svdTienda.id;
		this.idSubcategoria = dato.svdSubcategorias.id;
		this.idProducto = dato.idProducto;
		this.nombreProducto = dato.nombreProducto;
		this.descripcion = dato.descripcion;
		this.urlImagen = dato.urlImagen;
		this.urlImagenA = dato.urlImagenA;
		this.urlImagenB = dato.urlImagenB;
		this.urlImagenC = dato.urlImagenC;
		this.stock = dato.stock;
		this.precio = dato.precio;
		this.dimensiones = dato.dimensiones;
		this.peso = dato.peso;
		this.demoraEnvio = dato.demoraEnvio;
		this.mostrarFormulario=true;
		this.crud = 2;
		this.btnTitulo="Actualizar";
		this.medirNombreProductoNum(event);
		this.medirDescripcionNum(event);
	}

	eliminarDatos(dato){
		this.idTienda = dato.id; //Id tienda
		this.eliminarProducto();
		//this.abrirModal();
		this.crud = 3;
	}

	btnGuardar(){
		if (this.crud==1) { //Registrar
			this.crearProducto();
		}
		if (this.crud==2) { //Actualizar
			this.actualizarProducto();
		}
	}

	btnCancelar(){
		this.crud = 1;
		this.btnTitulo="Registrar";
		this.mostrarFormulario=false;
	}

	nuevoProducto(){
		this.mostrarFormulario=true;
		this.crud=1;
		this.btnTitulo="Registrar";
	}

	cargarArchivo(event,opt) {
		if (event.target.files.length > 0) {
			let file = event.target.files[0];  
		  	this.archivo.push({ data: file, inProgress: false, progress: 0});
		  	this.archivo.forEach(file => {  
				this.subirArchivo(file,opt);  
			});  
		}
	}

	subirArchivo(file,opt) {  
		const formData = new FormData(); 
		//bytes 1.11mb = 1,169,051 bytes
		formData.append('uploadedFile', file.data);
		let extension;
		if (file.data.type=="image/jpeg") {
            extension = ".jpeg";
        }
        if (file.data.type=="image/png") {
            extension = ".png";
        }
        this.urlImagen = "img-producto-"+this.idProducto+extension;
        if (opt=='-A') {
        	this.urlImagenA = "img-producto-"+this.idProducto+opt+extension;
        }
        if (opt=='-B') {
        	this.urlImagenB = "img-producto-"+this.idProducto+opt+extension;
        }
		if (opt=='-C') {
        	this.urlImagenC = "img-producto-"+this.idProducto+opt+extension;
        }
		formData.append('fileName', "img-producto-"+this.idProducto+opt);
		formData.append('fileType', file.data.type);
		formData.append('fileSize', file.data.size);
		file.inProgress = true;  
		this.datos.subirImgProducto(formData)
		.subscribe(data => {
			this.archivo = [];
			console.log("se subió archivo.");
			this.notifier.notify( 'msg-exito', 'Archivo subido con éxito.' );
		}, err => {
			if (err.status==413) {
				file.inProgress = false;  
				console.log("Archivo muy pesado.");
				this.notifier.notify( 'msg-error', 'Error, archivo muy pesado (máx. 1mb).' );
			}
			if (err.status==406) {
				file.inProgress = false;  
				console.log("Tipo de archivo no permitido.");
				this.notifier.notify( 'msg-error', 'Error , solo se permite jpeg, jpg o png.' );
			}
			if (err.status==500) {
				file.inProgress = false;  
				console.log("ocurrió un eror.");
				this.notifier.notify( 'msg-error', 'Error con el archivo.' );
			}
		});
		//file.progress = Math.round(event.loaded * 100 / event.total);    
	}

	urlProducto(dato){
		this.router.navigateByUrl("/producto/"+dato.idProducto);
	}


}
