import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmproductosComponent } from './admproductos.component';

describe('AdmproductosComponent', () => {
  let component: AdmproductosComponent;
  let fixture: ComponentFixture<AdmproductosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdmproductosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdmproductosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
