import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NotifierService } from 'angular-notifier';
import { AuthService } from '../auth.service';
import { DsService } from '../ds.service';

@Component({
	selector: 'app-carrito',
	templateUrl: './carrito.component.html',
	styleUrls: ['./carrito.component.css']
})
export class CarritoComponent implements OnInit {

	cantidad=0;
	lstCarrito;
	idComprador;
	carritoActivado=true;
	cajeroActivado=false;
	subtotal;
	total;
	stock;
	nombresCompletosVendedor;
	celularVendedor;
	productoCarritoSeleccionado;
	idProductoCarritoSeleccionado=0;
	nombreProductoSeleccionado;
	activarBtnEditarProducto = false;
	activarBtnCajero = true;
	//code cajero
	ocultarBotonesPago='';
	textoBtn='Siguiente paso';
	pasoActual='paso-1';
	paso1='';
	paso2='is-hidden';
	paso3='is-hidden';
	paso4='is-hidden';
	activo1='active';
	activo2='';
	activo3='';
	activo4='';

	idTipoPago=-1;
	datosPersona;

	imgProducto;

	precioProducto;
	imgProductoSeleccionado;

	assetsImg;

	constructor(private route: ActivatedRoute, private router: Router,
		private authService: AuthService, private notifier: NotifierService,
		private datos: DsService) { }

	ngOnInit(): void {
		this.imgProducto = this.datos.getImgProducto();
		this.idComprador = parseInt(this.authService.getIdUsuario());
		this.obtenerCarritoPorIdComprador();
		this.traerDatosPersonaPorId();
		this.assetsImg = this.datos.getAssetsImg();
	}

	irCajero(){
		if (this.productoCarritoSeleccionado!=null) {
			this.carritoActivado = false;
			this.cajeroActivado = true;
		} else {
			this.notifier.notify( 'msg-error', 'Debe seleccionar un producto.' );
		}
		
	}
	
	obtenerCarritoPorIdComprador(){
		this.datos.listarProductosEnCarritoPorIdComprador(this.idComprador)
		.subscribe(data => {
			console.log(data[0]);
			this.lstCarrito = data;
			if (data!=null) {
				this.nombreProductoSeleccionado = data[0].svdProducto.nombreProducto;
				this.imgProductoSeleccionado = data[0].svdProducto.urlImagen;
				this.total = data[0].svdProducto.costo;
				this.precioProducto = data[0].svdProducto.precio;
			}
			console.log("this.lstCarrito: "+this.lstCarrito);
			console.log("Los datos fueron cargados.");
		});
	}

	eliminarProductoCarrito(dato){
		let carrito = {};
		carrito["id"] = dato.id;
		this.datos.eliminarCarrito(carrito)
		.subscribe(data => {
			this.obtenerCarritoPorIdComprador();
			this.notifier.notify( 'msg-exito', 'El producto fue retirado del carrito.' );
			console.log(data);
		}, err => {
			if (err.status==500) {
				this.notifier.notify( 'msg-error', 'Error en la operación.' );
			}
			if (err.status==406) {
				this.notifier.notify( 'msg-error', 'Error, el vendedor ya tiene tienda.' );
			}
			console.log("Error en la operación: "+err.status+" err.msg ");
		});
	}

	seleccionarProductoCarrito(dato){
		this.productoCarritoSeleccionado = dato; //datos de producto seleccionado
		this.idProductoCarritoSeleccionado = dato.id;
		this.nombreProductoSeleccionado = dato.svdProducto.nombreProducto;
		this.stock = dato.svdProducto.stock;
		let nombres = dato.svdProducto.svdTienda.svdUsuarios.svdPersona.nombres;
		let apPaterno = dato.svdProducto.svdTienda.svdUsuarios.svdPersona.apPaterno;
		let apMaterno = dato.svdProducto.svdTienda.svdUsuarios.svdPersona.apMaterno;
		this.nombresCompletosVendedor = nombres+" "+apPaterno+" "+apMaterno;
		this.celularVendedor = dato.svdProducto.svdTienda.svdUsuarios.svdPersona.celular;
		this.cantidad = dato.cantidad;
		this.subtotal = dato.costo;
		this.total = dato.costo;
		this.precioProducto = dato.svdProducto.precio;
		this.imgProductoSeleccionado = dato.svdProducto.urlImagen;
		this.notifier.notify( 'msg-exito', 'Producto '+this.nombreProductoSeleccionado+' seleccionado.' );
	}

	editarProductoCarrito(dato){
		this.productoCarritoSeleccionado = dato; //datos de producto seleccionado
		this.activarBtnEditarProducto = true;
		this.activarBtnCajero = false;
		this.idProductoCarritoSeleccionado = dato.id;
		this.nombreProductoSeleccionado = dato.svdProducto.nombreProducto;
		this.stock = dato.svdProducto.stock;
		let nombres = dato.svdProducto.svdTienda.svdUsuarios.svdPersona.nombres;
		let apPaterno = dato.svdProducto.svdTienda.svdUsuarios.svdPersona.apPaterno;
		let apMaterno = dato.svdProducto.svdTienda.svdUsuarios.svdPersona.apMaterno;
		this.nombresCompletosVendedor = nombres+" "+apPaterno+" "+apMaterno;
		this.celularVendedor = dato.svdProducto.svdTienda.svdUsuarios.svdPersona.celular;
		this.cantidad = dato.cantidad;
		this.subtotal = dato.costo;
		this.total = dato.costo;
		this.precioProducto = dato.svdProducto.precio;
		this.imgProductoSeleccionado = dato.svdProducto.urlImagen;
		this.notifier.notify( 'msg-exito', 'Puede modificar cantidad de producto.' );
	}

	actualizarDatosCarrito(){
		this.activarBtnCajero = true;
		if (this.productoCarritoSeleccionado!=null) {
			console.log("this.productoCarritoSeleccionado.svdProducto: "+this.productoCarritoSeleccionado.svdProducto.nombreProducto);
			let carrito = {};
			carrito["id"] = this.productoCarritoSeleccionado.id;
			carrito["svdProducto"] = this.productoCarritoSeleccionado.svdProducto;
			carrito["svdUsuarios"] = this.productoCarritoSeleccionado.svdUsuarios;
			carrito["svdFasesOrden"] = this.productoCarritoSeleccionado.svdFasesOrden;
			carrito["svdTiposPago"] = this.productoCarritoSeleccionado.svdTiposPago;
			carrito["cantidad"] = this.cantidad;
			console.log("this.cantidad*precio :"+this.cantidad*this.productoCarritoSeleccionado.svdProducto.precio);
			carrito["costo"] = this.cantidad*this.productoCarritoSeleccionado.svdProducto.precio;
			this.datos.actualizarCarrito(carrito)
			.subscribe(data => {
				this.activarBtnEditarProducto = false;
				this.obtenerCarritoPorIdComprador();
				this.nombreProductoSeleccionado = "";
				this.subtotal = 0;
				this.total = 0;
				this.notifier.notify( 'msg-exito', 'Carrito actualizado.' );
				console.log(data);
			}, err => {
				if (err.status==500) {
					this.notifier.notify( 'msg-error', 'Error en la operación.' );
				}
				if (err.status==406) {
					this.notifier.notify( 'msg-error', 'No existe carrito para actualizar.' );
					this.activarBtnEditarProducto = false;
				}
				console.log("Error en la operación: "+err.status+" err.msg ");
			});
		} else {
			this.activarBtnEditarProducto = false;
			this.notifier.notify( 'msg-error', 'Debe seleccionar un producto.' );
		}
	}

	seleccionarTipoPago(id){
		this.idTipoPago = id;
		let tipoPago="";
		console.log("tipo de pago: "+this.idTipoPago);
		if (this.idTipoPago==1) {
			tipoPago="Yape";
		}
		if (this.idTipoPago==2) {
			tipoPago="Plin";
		}
		if (this.idTipoPago==0) {
			tipoPago="A tratar";
		}
		this.notifier.notify( 'msg-exito', 'El método de pago seleccionado fue: '+ tipoPago);
	}

	realizarOrdenCompra(){
		//this.activarBtnCajero = "";
		if (this.productoCarritoSeleccionado!=null) {
			let orden = {};
			orden["id"] = this.productoCarritoSeleccionado.id;
			let svdTiposPago = {};
			svdTiposPago["id"] = this.idTipoPago;
			orden["svdTiposPago"] = svdTiposPago;
			this.datos.ordenarProducto(orden)
			.subscribe(data => {
				this.obtenerCarritoPorIdComprador();
				this.notifier.notify( 'msg-exito', 'Hemos recibido su orden.' );
				console.log(data);
				//caso 3
				this.paso3='is-hidden';
				this.paso4='';
				this.activo3='';
				this.activo4='active';
				this.pasoActual='paso-4';
				this.ocultarBotonesPago='is-hidden';
				this.irPedidos();
			}, err => {
				if (err.status==500) {
					this.notifier.notify( 'msg-error', 'Error en la operación.' );
				}
				if (err.status==406) {
					this.notifier.notify( 'msg-error', 'No existe producto en carrito' );
					//this.activarBtnEditarProducto = "is-hidden";
				}
				console.log("Error en la operación: "+err.status+" err.msg ");
			});
		} else {
			this.notifier.notify( 'msg-error', 'Debe seleccionar un producto.' );
		}
	}

	mas(){
		if (this.cantidad<this.stock) {
			this.cantidad= this.cantidad+1;
		} else {
			this.notifier.notify( 'msg-error', 'No se puede exceder.' );
		}
	}

	menos(){
		if (this.cantidad<=1) {
			this.notifier.notify( 'msg-error', 'No se puede comprar menos de 1 producto.' );
		} else {
			this.cantidad= this.cantidad-1;
		}
	}

	traerDatosPersonaPorId(){
		let idPer = parseInt(this.authService.getIdPer());
		console.log("id de persona es: "+idPer);
		if (idPer==null) {
			console.log("id es null");
			this.notifier.notify( 'msg-error', 'Usted debe estar logueado.' );
		} else {
			console.log("id: "+idPer)
			this.datos.datosPersonaPorId(idPer)
			.subscribe(data => {
				//this.notifier.notify( 'msg-exito', 'Registro exitoso.' );
				this.datosPersona = data;
				console.log("datosPersona: "+this.datosPersona.nombres);
				console.log("datosPersona: "+this.datosPersona.apPaterno);
				
			}, err => {
				if (err.status==500) {
					this.notifier.notify( 'msg-error', 'Error al traer datos personales.' );
				}
				console.log("Error en la operación: "+err.status);
			});
		}
		
	}

	irPedidos(){
		this.router.navigateByUrl("/pedidos");
	}

}
