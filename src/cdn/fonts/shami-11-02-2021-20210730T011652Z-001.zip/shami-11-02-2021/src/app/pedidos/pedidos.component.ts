import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NotifierService } from 'angular-notifier';
import { AuthService } from '../auth.service';
import { DsService } from '../ds.service';

@Component({
	selector: 'app-pedidos',
	templateUrl: './pedidos.component.html',
	styleUrls: ['./pedidos.component.css']
})
export class PedidosComponent implements OnInit {

	lstCategorias;
	lstPedidos;
	idComprador;
	logueado;
	idDeseo;

	assetsImg;
	imgProducto;
	imgTienda;
	imgCategoria;

	constructor(private route: ActivatedRoute, private router: Router,
		private authService: AuthService, private notifier: NotifierService,
		private datos: DsService) { 
	}

	ngOnInit(): void {
		this.assetsImg = this.datos.getAssetsImg();
		this.imgProducto = this.datos.getImgProducto();
		this.imgTienda = this.datos.getImgTienda();
		this.imgCategoria = this.datos.getImgCategoria();
		this.obtenerCategorias();
		this.idComprador = parseInt(this.authService.getIdUsuario());
		this.obtenerListaPedidos();
		this.logueado = this.authService.isLoggedIn();
	}

	obtenerCategorias(){
		this.datos.listarCategorias()
		.subscribe(data => {
			this.lstCategorias = data;
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerListaPedidos(){
		console.log("obtenerListaPedidos -> this.idComprador: "+this.idComprador);
		this.datos.listarPedidosPorIdComprador(this.idComprador)
		.subscribe(data => {
			console.log(data[0]);
			this.lstPedidos = data;
			console.log("this.lstPedidos: "+this.lstPedidos);
			console.log("Los datos fueron cargados.");
		});
	}

	verMasPedidos(){

	}

	irProductos(dato){
		this.router.navigateByUrl("/productos/"+dato.id);
	}

	irProducto(dato){
		this.router.navigateByUrl("/producto/"+dato.svdProducto.idProducto);
	}

	irTienda(dato){
		this.router.navigateByUrl("/tienda/"+dato.svdProducto.svdTienda.id);
	}

}
