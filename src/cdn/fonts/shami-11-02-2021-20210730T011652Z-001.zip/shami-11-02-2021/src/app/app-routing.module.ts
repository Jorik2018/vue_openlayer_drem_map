import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InicioComponent } from './inicio/inicio.component';

import { TiendaComponent } from './tienda/tienda.component';
import { TiendasComponent } from './tiendas/tiendas.component';
import { ProductoComponent } from './producto/producto.component';
import { ProductosComponent } from './productos/productos.component';
import { CuentaComponent } from './cuenta/cuenta.component';
import { DeseosComponent } from './deseos/deseos.component';
import { PedidosComponent } from './pedidos/pedidos.component';
import { CarritoComponent } from './carrito/carrito.component';
import { AdmtiendasComponent } from './admtiendas/admtiendas.component';
import { AdmproductosComponent } from './admproductos/admproductos.component';
import { AdmusuariosComponent } from './admusuarios/admusuarios.component';
import { AdmpedidosComponent } from './admpedidos/admpedidos.component';
import { AdmconfigComponent } from './admconfig/admconfig.component';

import { TerminosCondicionesComponent } from './terminos-condiciones/terminos-condiciones.component';

import { LoginGuard } from './login.guard';

const routes: Routes = [
	{path: '', redirectTo: 'inicio', pathMatch: 'full'},
	{path: 'inicio', component: InicioComponent},
	{path: 'tienda/:id', component: TiendaComponent},
	{path: 'tiendas/:id', component: TiendasComponent},
	{path: 'producto/:id', component: ProductoComponent},
	{path: 'productos/:id', component: ProductosComponent},
	{path: 'cuenta', component: CuentaComponent, canActivate: [LoginGuard]},
	{path: 'deseos', component: DeseosComponent, canActivate: [LoginGuard]},
	{path: 'pedidos', component: PedidosComponent, canActivate: [LoginGuard]},
	{path: 'carrito', component: CarritoComponent, canActivate: [LoginGuard]},
	{path: 'admtiendas', component: AdmtiendasComponent, canActivate: [LoginGuard]},
	{path: 'admproductos', component: AdmproductosComponent, canActivate: [LoginGuard]},
	{path: 'admusuarios', component: AdmusuariosComponent, canActivate: [LoginGuard]},
	{path: 'admpedidos', component: AdmpedidosComponent, canActivate: [LoginGuard]},
	{path: 'admconfig', component: AdmconfigComponent, canActivate: [LoginGuard]},
	{path: 'terminos-condiciones', component: TerminosCondicionesComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
