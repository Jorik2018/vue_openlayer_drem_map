import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NotifierService } from 'angular-notifier';
import { AuthService } from '../auth.service';
import { DsService } from '../ds.service';
import { MetadataService } from '../metadata.service';

@Component({
	selector: 'app-inicio',
	templateUrl: './inicio.component.html',
	styleUrls: ['./inicio.component.css']
})
export class InicioComponent implements OnInit {

	lstProductos;
	lstProductosRecientes;
	lstProductosPopulares;
	lstCategorias;
	
	pagina=1;
	cantidad=4;
	paginaRecientes=1;
	cantidadRecientes=4;
	paginaPopulares=1;
	cantidadPopulares=16;

	assetsImg;
	imgProducto;
	imgTienda;
	imgCategoria;

	idProducto;
	idComprador;
	logueado;

	constructor(private route: ActivatedRoute, private router: Router,
	private authService: AuthService, private notifier: NotifierService,
	private datos: DsService, private metadata: MetadataService) { }

	ngOnInit(): void {
		this.metadata.updateTags('Inicio', 'inicio');
		this.assetsImg = this.datos.getAssetsImg();
		this.imgProducto = this.datos.getImgProducto();
		this.imgTienda = this.datos.getImgTienda();
		this.imgCategoria = this.datos.getImgCategoria();
		this.obtenerCategorias();
		this.obtenerProductosPaginados();
		this.obtenerProductosRecientesPaginados();
		this.obtenerProductosPopularesPaginados();
		this.idComprador = parseInt(this.authService.getIdUsuario());
		this.logueado = this.authService.isLoggedIn();
	}

	obtenerProductosPaginados(){
		this.datos.paginarProductos(this.pagina,this.cantidad)
		.subscribe(data => {
			this.lstProductos = data;
			console.log("Los datos fueron cargados.");
		});
	}

	verMasProductos(){
		this.pagina = this.pagina+1;
		this.datos.paginarProductos(this.pagina,this.cantidad)
		.subscribe(data => {
			if (data!=null) {
				this.lstProductos = this.lstProductos.concat(data);
			} else {

			}
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerProductosRecientesPaginados(){
		this.datos.paginarProductosRecientes(this.paginaRecientes,this.cantidadRecientes)
		.subscribe(data => {
			this.lstProductosRecientes = data;
			console.log("Los datos fueron cargados.");
		});
	}

	verMasProductosRecientes(){
		this.paginaRecientes = this.paginaRecientes+1;
		this.datos.paginarProductosRecientes(this.paginaRecientes,this.cantidadRecientes)
		.subscribe(data => {
			if (data!=null) {
				this.lstProductosRecientes = this.lstProductosRecientes.concat(data);
			} else {

			}
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerProductosPopularesPaginados(){
		this.datos.paginarProductos(this.paginaPopulares,this.cantidadPopulares)
		.subscribe(data => {
			this.lstProductosPopulares = data;
			console.log("Los datos fueron cargados.");
		});
	}

	verMasProductosPopulares(){
		this.paginaPopulares = this.paginaPopulares+1;
		this.datos.paginarProductos(this.paginaPopulares,this.cantidadPopulares)
		.subscribe(data => {
			if (data!=null) {
				this.lstProductosPopulares = this.lstProductosPopulares.concat(data);
			} else {

			}
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerCategorias(){
		this.datos.listarCategorias()
		.subscribe(data => {
			this.lstCategorias = data;
			console.log("Los datos fueron cargados.");
		});
	}

	crearDeseo(dato){
		if (this.logueado) {
			this.idProducto = dato.idProducto;
			let deseo = {};
			let svdProducto = {};
			svdProducto["idProducto"] = this.idProducto;
			deseo["svdProducto"] = svdProducto;
			let svdUsuarios = {}
			svdUsuarios["id"] = this.idComprador;
			deseo["svdUsuarios"] = svdUsuarios;
			this.datos.crearDeseo(deseo)
			.subscribe(data => {
				this.notifier.notify( 'msg-exito', 'Producto agregado a lista de deseos.' );
				console.log(data);
			}, err => {
				if (err.status==500) {
					this.notifier.notify( 'msg-error', 'Error en la operación.' );
				}
				if (err.status==406) {
					this.notifier.notify( 'msg-error', 'Error, el vendedor ya tiene tienda.' );
				}
				console.log("Error en la operación: "+err.status+" err.msg ");
			});
		} else {
			this.notifier.notify( 'msg-error', 'Debe iniciar sesión.' );
		}
	}

	irProductos(){
    	this.router.navigateByUrl("/productos");
    }

    irProductosPorCategoria(dato){
		this.router.navigateByUrl("/productos/"+dato.id);
	}

	irProducto(dato){
		this.router.navigateByUrl("/producto/"+dato.idProducto);
	}

	irTienda(dato){
		this.router.navigateByUrl("/tienda/"+dato.svdTienda.id);
	}

}
