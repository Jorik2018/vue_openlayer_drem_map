import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AuthService } from '../auth.service';
import { DsService } from '../ds.service';
import { NotifierService } from 'angular-notifier';

@Component({
	selector: 'menuadm',
	templateUrl: './menuadm.component.html',
	styleUrls: ['./menuadm.component.css']
})
export class MenuadmComponent implements OnInit {

	_bandMenuEspecial=false;
	idRol=0;
    rol="";
    admTiendas=false;
    admProductos=false;
    admPedidos=false;
    admUsuarios=false;
    admConfig=false;

	constructor(private spinner: NgxSpinnerService,
		private route: ActivatedRoute, private router: Router,
        private authService: AuthService, private datos: DsService,
        private notifier: NotifierService) { 
    }

	ngOnInit(): void {
	}

	get bandMenuEspecial() {
        if (this.authService.isLoggedIn()) {
            //console.log("id usuario: "+this.authService.getIdUsuario());
            this.idRol = parseInt(this.authService.getIdRol());
            //console.log("this.idRol en bandMenuEspecial es: "+this.idRol);
            //console.log("_bandMenuEspecial: "+this._bandMenuEspecial);
            if (this.idRol!=3) {
                this._bandMenuEspecial = true;
            } else {
                this._bandMenuEspecial = false;
            }
            if (this.idRol==1) {
                this.rol = "Vendedor";
                this.admTiendas=true;
                this.admProductos=true;
                this.admPedidos=true;
                this.admUsuarios=true;
                this.admConfig=false;
            }
            if (this.idRol==2) {
                this.rol = "Repartidor";
                this.admPedidos=true;
                this.admTiendas=false;
                this.admProductos=false;
                this.admUsuarios=false;
                this.admConfig=false;
            }
            if (this.idRol==4) {
                this.rol = "Admin";
                this.admTiendas=true;
                this.admProductos=true;
                this.admPedidos=true;
                this.admUsuarios=true;
                this.admConfig=true;
            }
        } else {
            this._bandMenuEspecial = false;
        }
        return this._bandMenuEspecial;
    }

    irAdmTiendas(){
        this.router.navigateByUrl("/admtiendas");
    }

    irAdmProductos(){
        this.router.navigateByUrl("/admproductos");
    }

    irAdmPedidos(){
        this.router.navigateByUrl("/admpedidos");
    }

    irAdmUsuarios(){
        this.router.navigateByUrl("/admusuarios");
    }

    irAdmConfig(){
        this.router.navigateByUrl("/admconfig");
    }

}
