import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmpedidosComponent } from './admpedidos.component';

describe('AdmpedidosComponent', () => {
  let component: AdmpedidosComponent;
  let fixture: ComponentFixture<AdmpedidosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdmpedidosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdmpedidosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
