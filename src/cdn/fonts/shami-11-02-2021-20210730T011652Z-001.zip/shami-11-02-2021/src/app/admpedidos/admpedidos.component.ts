import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NotifierService } from 'angular-notifier';
import { AuthService } from '../auth.service';
import { DsService } from '../ds.service';


@Component({
	selector: 'app-admpedidos',
	templateUrl: './admpedidos.component.html',
	styleUrls: ['./admpedidos.component.css']
})
export class AdmpedidosComponent implements OnInit {

	mostrarFormulario=false;
	btnTitulo="Actualizar";
	crud=0;
	modal="";
	idRol;
	idUsuario;
	lstPedidos;
	lstRepartidores;
	idPedido;
	nombreProducto;
	nombreComprador;
	idRepartidor;
	lstEnvios;
	idEnvio;
	mostrarInfoComprador=false;
	nombres;
	apellidos;
	direccionCompleta;
	celular;

	constructor(private route: ActivatedRoute, private router: Router,
		private authService: AuthService, private notifier: NotifierService,
		private datos: DsService) { }

	ngOnInit(): void {
		this.idRol = parseInt(this.authService.getIdRol());
		this.idUsuario = parseInt(this.authService.getIdUsuario());
		if (this.idRol==4) {
			this.obtenerPedidos();
		}
		if (this.idRol==1) {
			this.obtenerPedidosPorIdVendedor();
			this.obtenerRepartidores();
			//this.idVendedor = this.idUsuario;
		}
		if (this.idRol==2) {
			this.obtenerEnviosPorIdVendedor();
		}
	}

	obtenerPedidos(){
		this.datos.listarTodosLosPedidos()
		.subscribe(data => {
			this.lstPedidos = data;
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerPedidosPorIdVendedor(){
		this.datos.listarPedidosPorIdVendedor(this.idUsuario)
		.subscribe(data => {
			this.lstPedidos = data;
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerEnviosPorIdVendedor(){
		this.datos.listarEnviosPorIdVendedor(this.idUsuario)
		.subscribe(data => {
			this.lstEnvios = data;
			console.log("Los datos fueron cargados.");
		});
	}

	obtenerRepartidores(){
		this.datos.listarRepartidores()
		.subscribe(data => {
			this.lstRepartidores = data;
			console.log("this.lstRepartidores: "+this.lstRepartidores);
			console.log("Los datos fueron cargados.");
		});
	}

	atenderPedido(dato){
		this.idPedido = dato.id
		let orden = {};
		orden["id"] = this.idPedido;
		this.datos.atenderPedido(orden)
		.subscribe(data => {
			this.notifier.notify( 'msg-exito', 'Pedido atendido.' );
			if (this.idRol==4) {
				//this.obtenerUsuarios();
			}
			if (this.idRol==1) {
				this.obtenerPedidosPorIdVendedor();
				//this.obtenerRepartidores();
			}
		}, err => {
			if (err.status==500) {
				this.notifier.notify( 'msg-error', 'Error en la operación.' );
			}
			if (err.status==406) {
				this.notifier.notify( 'msg-error', 'Error, no existe pedido.' );
			}
			console.log("Error en la operación: "+err.status+" err.msg ");
		});
	}

	asignarRepartidor(){
		let envio = {};
		let svdUsuarios = {};
		svdUsuarios["id"] = this.idRepartidor;
		let svdOrden = {};
		svdOrden["id"] = this.idPedido;
		envio["svdUsuarios"] = svdUsuarios;
		envio["svdOrden"] = svdOrden;
		this.datos.asignarRepartidor(envio)
		.subscribe(data => {
			this.notifier.notify( 'msg-exito', 'Actualización exitosa.' );
			if (this.idRol==4) {
			}
			if (this.idRol==1) {
				this.obtenerPedidosPorIdVendedor();
			}
		}, err => {
			if (err.status==500) {
				this.notifier.notify( 'msg-error', 'Error en la operación.' );
			}
			if (err.status==406) {
				this.notifier.notify( 'msg-error', 'Error, no existe el usuario.' );
			}
			console.log("Error en la operación: "+err.status+" err.msg ");
		});
	}

	confirmarEntregaPedido(dato){
		this.idEnvio = dato.id
		let envio = {};
		envio["id"] = this.idEnvio;
		let svdOrden = {};
		svdOrden["id"] = dato.svdOrden.id;
		envio["svdOrden"] = svdOrden;
		this.datos.confirmarEntregaPedido(envio)
		.subscribe(data => {
			this.notifier.notify( 'msg-exito', 'Pedido entregado.' );
			if (this.idRol==4) {
			}
			if (this.idRol==1) {
			}
			if (this.idRol==2) {
				this.obtenerEnviosPorIdVendedor();
			}
		}, err => {
			if (err.status==500) {
				this.notifier.notify( 'msg-error', 'Error en la operación.' );
			}
			if (err.status==406) {
				this.notifier.notify( 'msg-error', 'Error, no existe envío.' );
			}
			console.log("Error en la operación: "+err.status+" err.msg ");
		});
	}

	editarAsignar(dato){
		this.idPedido = dato.id; //Id pedido - orden
		this.nombreProducto = dato.svdProducto.nombreProducto;
		this.nombreComprador = dato.svdUsuarios.svdPersona.nombres;
		this.mostrarFormulario=true;
		this.crud = 2;
		this.btnTitulo="Asignar repartidor";
	}

	verInfoComprador(dato){
		this.mostrarInfoComprador = true;
		this.nombres = dato.svdOrden.svdUsuarios.svdPersona.nombres;
		this.apellidos = dato.svdOrden.svdUsuarios.svdPersona.apPaterno + " "+ dato.svdOrden.svdUsuarios.svdPersona.apMaterno;
		this.direccionCompleta = dato.svdOrden.svdUsuarios.svdPersona.urbanizacion + " " + dato.svdOrden.svdUsuarios.svdPersona.sector + " " + dato.svdOrden.svdUsuarios.svdPersona.manzana + " " + dato.svdOrden.svdUsuarios.svdPersona.lote;
		this.celular = dato.svdOrden.svdUsuarios.svdPersona.celular;
	}

	btnGuardar(){
		this.asignarRepartidor();
		if (this.crud==1) { //Registrar
			
		}
		if (this.crud==2) { //Actualizar Asignar repartidor
		
		}
	}

	btnCancelar(){
		this.crud = 1;
		//this.btnTitulo="Registrar";
		this.mostrarFormulario=false;
	}

}
